package com.maykel.routermac

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {
    private lateinit var ip: EditText
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var block: Button
    private lateinit var unblock: Button
    private lateinit var mac: EditText

    private val cookieJar = SimpleCookieJar()
    private val client = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    private var sessionKey: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ip = findViewById(R.id.routerIp)
        status = findViewById(R.id.status)
        details = findViewById(R.id.details)
        block = findViewById(R.id.block)
        unblock = findViewById(R.id.unblock)
        mac = findViewById(R.id.mac)

        findViewById<Button>(R.id.connect).setOnClickListener { connect() }

        block.setOnClickListener { sendMacFilter("add") }
        unblock.setOnClickListener { sendMacFilter("delete") }
    }

    private fun connect() {
        val host = ip.text.toString().trim().removePrefix("http://").removeSuffix("/")
        status.text = "Conectando a $host…"

        Thread {
            try {
                val request = Request.Builder().url("http://$host/").get().build()
                client.newCall(request).execute().use { response ->
                    val html = response.body?.string().orEmpty()

                    sessionKey = extract(html,
                        """(?:gcsessionkey|sessionkey)\s*=\s*["']([^"']+)["']""")
                        ?: extract(html, """name=["']sessionkey["'][^>]*value=["']([^"']+)["']""")
                    val localMac = extract(html, """localmac\s*=\s*["']([^"']+)["']""")
                    val mode = extract(html, """filtermode\s*=\s*["']([^"']+)["']""")

                    runOnUiThread {
                        if (response.isSuccessful) {
                            status.text = "Router conectado ✓"
                            details.text =
                                "HTTP ${response.code}\n" +
                                "Session: ${sessionKey ?: "no encontrada"}\n" +
                                "MAC local: ${localMac ?: "no encontrada"}\n" +
                                "Modo: ${mode ?: "no encontrado"}"
                            block.isEnabled = sessionKey != null
                            unblock.isEnabled = sessionKey != null
                        } else {
                            status.text = "El router respondió HTTP ${response.code}"
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Error: ${e.message}"
                    details.text = "Comprueba que el teléfono esté conectado al Wi‑Fi del router."
                }
            }
        }.start()
    }

    private fun sendMacFilter(operation: String) {
        val host = ip.text.toString().trim().removePrefix("http://").removeSuffix("/")
        val targetMac = mac.text.toString().trim().lowercase()
        if (!Regex("^[0-9a-f]{2}(:[0-9a-f]{2}){5}$").matches(targetMac)) {
            mac.error = "Usa AA:BB:CC:DD:EE:FF"
            return
        }
        val key = sessionKey
        if (key.isNullOrBlank()) {
            status.text = "Primero conecta con el router"
            return
        }

        status.text = if (operation == "add") "Bloqueando $targetMac…" else "Desbloqueando $targetMac…"
        Thread {
            try {
                val form = FormBody.Builder()
                    .add("onSubmit", "1")
                    .add("sessionkey", key)
                    .add("operation", operation)
                    .add("delnumberlist", if (operation == "delete") "1" else "")
                    .add("filter_enable", "")
                    .add("modify_index", "")
                    .add("src_macaddress", targetMac)
                    .add("dst_macaddress", "")
                    .add("macfilter_enable", "on")
                    .add("macfilter_mode", "Exclude")
                    .add("filter_selectindex", "1")
                    .add("macfilter_protocol", "IP")
                    .add("macfilter_scmac", "")
                    .add("macfilter_dsmac", "")
                    .build()

                val request = Request.Builder()
                    .url("http://$host/cgi-bin/macfilter.cgi")
                    .post(form)
                    .header("Origin", "http://$host")
                    .header("Referer", "http://$host/cgi-bin/macfilter.cgi")
                    .build()

                client.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    runOnUiThread {
                        if (response.isSuccessful) {
                            status.text = if (operation == "add") "MAC enviada al filtro ✓" else "Petición de desbloqueo enviada ✓"
                            details.text = "HTTP ${response.code}\nOperación: $operation\nMAC: $targetMac\nRespuesta: ${body.take(180)}"
                        } else {
                            status.text = "El router respondió HTTP ${response.code}"
                            details.text = body.take(500)
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Error enviando la petición: ${e.message}" }
            }
        }.start()
    }

    private fun extract(text: String, regex: String): String? {
        val m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(text)
        return if (m.find()) m.group(1) else null
    }
}

class SimpleCookieJar : CookieJar {
    private val cookies = mutableListOf<Cookie>()

    @Synchronized override fun saveFromResponse(url: HttpUrl, newCookies: List<Cookie>) {
        newCookies.forEach { incoming ->
            cookies.removeAll {
                it.name == incoming.name && it.domain == incoming.domain && it.path == incoming.path
            }
            cookies.add(incoming)
        }
    }

    @Synchronized override fun loadForRequest(url: HttpUrl): List<Cookie> =
        cookies.filter { it.matches(url) }
}
