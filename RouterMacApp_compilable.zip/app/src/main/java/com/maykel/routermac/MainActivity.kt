package com.maykel.routermac

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {
    companion object {
        private const val ROUTER_USER = "admin"
        private const val ROUTER_PASSWORD = "system"
    }

    private lateinit var ip: EditText
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var block: Button
    private lateinit var unblock: Button
    private lateinit var mac: EditText
    private lateinit var web: WebView

    private var connected = false
    private var currentBase = "http://192.168.1.1"
    private var currentPageLooksLikeMacFilter = false
    private var operationRunning = false
    private var pendingOperation: String? = null
    private var pendingMac: String? = null
    private var inspectAttempts = 0
    private var loginAttempts = 0
    private var operationVerifyAttempts = 0
    private var macFilterUrl: String? = null
    private var sessionRecoveryRunning = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ip = findViewById(R.id.routerIp)
        status = findViewById(R.id.status)
        details = findViewById(R.id.details)
        block = findViewById(R.id.block)
        unblock = findViewById(R.id.unblock)
        mac = findViewById(R.id.mac)
        web = findViewById(R.id.routerWeb)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        web.settings.allowFileAccess = true
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                val m = (message ?: "").lowercase(Locale.US)
                // Some old router CGI versions signal a missing login password
                // with JavaScript alert() instead of rendering a login form.
                // Do not leave the user stuck at that dialog: retry the automatic
                // login against the same WebView/session.
                if (m.contains("session timeout") || m.contains("session timed out") ||
                    m.contains("please login again") || m.contains("login again")) {
                    result?.cancel()
                    recoverSessionIfNeeded()
                    return true
                }
                if (m.contains("password") || m.contains("contraseña") ||
                    m.contains("passwd") || m.contains("pass word")) {
                    // This firmware can emit the password warning from
                    // /cgi-bin/login.cgi before the real login form is loaded.
                    // Do not try to fill that (wrong) document. Dismiss the
                    // alert and open the actual login CGI in the same WebView.
                    result?.cancel()
                    recoverSessionIfNeeded()
                    return true
                }
                return super.onJsAlert(view, url, message, result)
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun onReceivedHttpAuthRequest(
                view: WebView?,
                handler: android.webkit.HttpAuthHandler?,
                host: String?,
                realm: String?
            ) {
                // Some firmware revisions protect the CGI with HTTP Basic/Digest
                // authentication instead of a normal HTML login form. Use the
                // router credentials supplied for this app automatically.
                handler?.proceed(ROUTER_USER, ROUTER_PASSWORD)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                inspectAttempts = 0
                if (sessionRecoveryRunning) {
                    // A router session timeout sends us back through its login CGI.
                    // Re-authenticate in the SAME WebView, then return to the exact
                    // MAC Filter URL we were using. This keeps the router cookies/session
                    // instead of starting a second WebView/session.
                    view?.postDelayed({ autoLogin() }, 250)
                } else if (operationRunning && pendingOperation != null) {
                    // Apply/Delete can reload the CGI page. The firmware may invalidate
                    // the CGI session at this point, so first detect whether this is a
                    // login page. If it is, recover the session before verifying.
                    view?.postDelayed({ inspectOperationPage() }, 250)
                } else {
                    view?.postDelayed({ inspectRouterPage() }, 250)
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                // Keep every CGI navigation inside the same WebView so the
                // router's own cookies/session state are never lost.
                return false
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        findViewById<Button>(R.id.connect).setOnClickListener { connect() }
        block.setOnClickListener { performMacOperation("add") }
        unblock.setOnClickListener { performMacOperation("delete") }
        setButtons(false)
    }

    private fun baseUrl(): String {
        var host = ip.text.toString().trim()
        if (host.isBlank()) host = "192.168.1.1"
        host = host.removePrefix("http://").removePrefix("https://")
        host = host.substringBefore('/').trim().trimEnd('/')
        return "http://$host"
    }

    private fun connect() {
        currentBase = baseUrl()
        connected = false
        currentPageLooksLikeMacFilter = false
        operationRunning = false
        inspectAttempts = 0
        loginAttempts = 0
        setButtons(false)
        status.text = "Conectando al router…"
        details.text = "Abriendo la interfaz CGI y conservando la misma sesión."

        // login.cgi on this firmware is only a bootstrap page. It can show
        // "Please entry the password" before redirecting to need_login.cgi.
        // Going directly to the real login CGI avoids losing the first session
        // while the WebView handles that alert.
        web.loadUrl("$currentBase/cgi-bin/need_login.cgi")
        web.postDelayed({ autoLogin() }, 650)
    }

    private fun recoverSessionIfNeeded() {
        if (currentBase.isBlank()) return
        if (sessionRecoveryRunning) return
        sessionRecoveryRunning = true
        loginAttempts = 0
        status.text = "Sesión del router caducada…"
        details.text = "Volviendo a iniciar sesión y conservando la misma conexión CGI."
        web.loadUrl("$currentBase/cgi-bin/need_login.cgi")
    }

    private fun inspectOperationPage() {
        val js = """
            (function(){
              var t=((document.body&&document.body.innerText)||'').replace(/\s+/g,' ').toLowerCase();
              if(t.indexOf('source mac address')>=0 || t.indexOf('current entry number')>=0 ||
                 t.indexOf('mac filter enable')>=0) return 'MAC_PAGE';
              var p=document.querySelectorAll('input[type=password],input[name*=pass i],input[id*=pass i]');
              if(p.length>0 || t.indexOf('session timeout')>=0 || t.indexOf('please login again')>=0 ||
                 t.indexOf('username')>=0) return 'LOGIN_PAGE';
              return 'OTHER';
            })();
        """.trimIndent()
        web.evaluateJavascript(js) { raw ->
            when (decodeJsResult(raw)) {
                "LOGIN_PAGE" -> {
                    recoverSessionIfNeeded()
                }
                "MAC_PAGE" -> {
                    sessionRecoveryRunning = false
                    verifyOperationAfterNavigation()
                }
                else -> {
                    // A redirect can briefly land on a blank/bootstrap CGI page.
                    // Give it a moment before deciding that verification failed.
                    web.postDelayed({ verifyOperationAfterNavigation() }, 350)
                }
            }
        }
    }

    private fun inspectRouterPage() {
        if (operationRunning) return

        val js = """
            (function(){
              function walk(w, out, depth){
                if(depth > 8) return;
                try { out.push(w.document); } catch(e) {}
                try {
                  for(var i=0;i<w.frames.length;i++) walk(w.frames[i],out,depth+1);
                } catch(e){}
              }
              function textOf(e){
                return (((e.innerText||e.value||e.textContent||e.title||e.alt||'')+'')
                  .replace(/\s+/g,' ').trim());
              }
              function hrefOf(e){ try{return (e.getAttribute('href')||'').trim();}catch(x){return '';} }

              var ds=[]; walk(window,ds,0);
              var allText='';
              for(var d=0;d<ds.length;d++){
                try{
                  allText += ' ' + (ds[d].body ? ds[d].body.innerText : '');
                  var els=ds[d].querySelectorAll('a,button,input,area,[onclick]');
                  for(var i=0;i<els.length;i++){
                    var e=els[i], t=textOf(e), h=hrefOf(e);
                    var ss=(t+' '+h).toLowerCase();
                    if(ss.indexOf('mac filter')>=0 || ss.indexOf('mac_filter')>=0 ||
                       ss.indexOf('macfilter')>=0){
                      if(h && h !== '#' && !/^javascript:/i.test(h)){
                        return 'MAC_HREF:'+h;
                      }
                      try{ e.click(); return 'MAC_CLICKED'; }catch(x){}
                    }
                  }
                }catch(e){}
              }

              var lower=allText.toLowerCase();

              // Detect the actual MAC Filter page before looking for login
              // words because its navigation/menu may contain "login".
              if(lower.indexOf('source mac address')>=0 ||
                 lower.indexOf('mac filter enable')>=0 ||
                 lower.indexOf('current entry number')>=0){
                return 'MAC_PAGE';
              }

              // The router's real login page normally has a password field.
              for(var q=0;q<ds.length;q++){
                try{
                  var pws=ds[q].querySelectorAll('input[type=password],input[name*=pass i],input[id*=pass i]');
                  if(pws.length>0) return 'LOGIN_PAGE';
                }catch(e){}
              }

              if(lower.indexOf('need_login')>=0 ||
                 lower.indexOf('please entry the password')>=0 ||
                 lower.indexOf('password')>=0 ||
                 lower.indexOf('username')>=0 ||
                 lower.indexOf('login')>=0){
                return 'LOGIN_PAGE';
              }
              return 'OTHER';
            })();
        """.trimIndent()

        web.evaluateJavascript(js) { raw ->
            val r = decodeJsResult(raw)
            when {
                r == "MAC_PAGE" -> {
                    connected = true
                    currentPageLooksLikeMacFilter = true
                    web.url?.let { if (it.isNotBlank()) macFilterUrl = it }
                    loginAttempts = 0
                    status.text = "Router conectado ✓"
                    details.text = "MAC Filter encontrada. Los botones están listos."
                    setButtons(true)
                }

                r.startsWith("MAC_HREF:") -> {
                    val href = r.removePrefix("MAC_HREF:")
                    status.text = "Abriendo MAC Filter…"
                    details.text = "Encontré la página MAC Filter."
                    setButtons(false)
                    val target = when {
                        href.startsWith("http://") || href.startsWith("https://") -> href
                        href.startsWith("/") -> "$currentBase$href"
                        else -> "$currentBase/$href"
                    }
                    web.post { web.loadUrl(target) }
                }

                r == "MAC_CLICKED" -> {
                    status.text = "Abriendo MAC Filter…"
                    details.text = "Encontré MAC Filter en el menú del router."
                    setButtons(false)
                    web.postDelayed({ inspectRouterPage() }, 700)
                }

                r == "LOGIN_PAGE" -> {
                    if (loginAttempts < 4) {
                        loginAttempts++
                        status.text = "Iniciando sesión en el router…"
                        details.text = "Introduciendo automáticamente admin / system."
                        web.postDelayed({ autoLogin() }, 250)
                    } else {
                        connected = false
                        currentPageLooksLikeMacFilter = false
                        setButtons(false)
                        status.text = "El router pide iniciar sesión"
                        details.text = "El formulario no aceptó automáticamente las credenciales."
                    }
                }

                else -> {
                    if (inspectAttempts < 12) {
                        inspectAttempts++
                        web.postDelayed({ inspectRouterPage() }, 450)
                    } else {
                        connected = false
                        currentPageLooksLikeMacFilter = false
                        setButtons(false)
                        status.text = "Router conectado, pero no encontré MAC Filter"
                        details.text = "La interfaz respondió, pero no localicé la página MAC Filter."
                    }
                }
            }
        }
    }

    private fun autoLogin() {
        val user = jsQuote(ROUTER_USER)
        val pass = jsQuote(ROUTER_PASSWORD)
        val js = """
            (function(){
              var USER=$user, PASS=$pass;

              function walk(w,out,depth){
                if(depth>8)return;
                try{out.push(w.document);}catch(e){}
                try{for(var i=0;i<w.frames.length;i++)walk(w.frames[i],out,depth+1);}catch(e){}
              }
              function clean(s){
                return ((s||'')+'').replace(/\s+/g,' ').trim().toLowerCase();
              }
              function desc(e){
                var s='';
                try{
                  s+=' '+clean(e.name)+' '+clean(e.id)+' '+clean(e.type)+
                     ' '+clean(e.placeholder)+' '+clean(e.title)+
                     ' '+clean(e.getAttribute('aria-label'));
                }catch(x){}
                try{
                  if(e.labels) for(var i=0;i<e.labels.length;i++)
                    s+=' '+clean(e.labels[i].innerText||e.labels[i].textContent);
                }catch(x){}
                return s;
              }
              function put(e,v){
                try{
                  var p=e.ownerDocument.defaultView.HTMLInputElement.prototype;
                  var d=Object.getOwnPropertyDescriptor(p,'value');
                  if(d&&d.set)d.set.call(e,v); else e.value=v;
                }catch(x){try{e.value=v;}catch(y){}}
                try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(x){}
                try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(x){}
              }
              function click(e){
                try{e.click();return true;}catch(x){}
                try{
                  var ev=e.ownerDocument.createEvent('MouseEvents');
                  ev.initMouseEvent('click',true,true,e.ownerDocument.defaultView,
                    1,0,0,0,0,false,false,false,false,0,null);
                  e.dispatchEvent(ev);return true;
                }catch(x){}
                return false;
              }

              var ds=[];walk(window,ds,0);
              for(var d=0;d<ds.length;d++){
                try{
                  var doc=ds[d];
                  var inputs=doc.querySelectorAll('input,textarea');
                  var pw=null, un=null;

                  // Prefer a real password input.
                  for(var i=0;i<inputs.length;i++){
                    var e=inputs[i], typ=clean(e.type), l=desc(e);
                    if(typ==='password' ||
                       l.indexOf('password')>=0 || l.indexOf('passwd')>=0 ||
                       l.indexOf('pwd')>=0 || l.indexOf('psw')>=0){
                      pw=e;break;
                    }
                  }

                  // Some old CGI versions use a text field for the password.
                  if(!pw){
                    for(var j=0;j<inputs.length;j++){
                      var t=inputs[j], tl=desc(t);
                      if(tl.indexOf('password')>=0 || tl.indexOf('passwd')>=0 ||
                         tl.indexOf('pwd')>=0 || tl.indexOf('psw')>=0){
                        pw=t;break;
                      }
                    }
                  }
                  if(!pw) continue;

                  // Username is optional on some firmware.
                  for(var k=0;k<inputs.length;k++){
                    var u=inputs[k], ut=clean(u.type), ul=desc(u);
                    if(u===pw || ut==='password' || ut==='hidden') continue;
                    if(ut==='text' || ut==='email' || ut==='tel' || ut===''){
                      if(ul.indexOf('user')>=0 || ul.indexOf('userid')>=0 ||
                         ul.indexOf('username')>=0 || ul.indexOf('login')>=0 ||
                         ul.indexOf('account')>=0){
                        un=u;break;
                      }
                    }
                  }

                  if(un) put(un,USER);
                  put(pw,PASS);

                  var form=pw.form;
                  if(form){
                    // First try the form's actual submit control.
                    var bs=form.querySelectorAll('input,button,a');
                    for(var b=0;b<bs.length;b++){
                      var bt=desc(bs[b])+' '+clean(bs[b].value||bs[b].innerText||bs[b].textContent);
                      if(bt.indexOf('login')>=0 || bt.indexOf('sign in')>=0 ||
                         bt.indexOf('entrar')>=0 || bt.indexOf('ingresar')>=0 ||
                         bt.indexOf('submit')>=0 || bt===' ok'){
                        click(bs[b]); return 'SUBMITTED';
                      }
                    }
                    // Fallback: submit the same form without navigating to a
                    // different origin, preserving the router session.
                    try{
                      if(form.requestSubmit){form.requestSubmit();return 'SUBMITTED';}
                    }catch(x){}
                    try{
                      HTMLFormElement.prototype.submit.call(form);
                      return 'SUBMITTED';
                    }catch(x){}
                  }

                  // No form: find a nearby login/OK control.
                  var all=doc.querySelectorAll('input[type=submit],input[type=button],button,a');
                  for(var c=0;c<all.length;c++){
                    var ct=desc(all[c])+' '+clean(all[c].value||all[c].innerText||all[c].textContent);
                    if(ct.indexOf('login')>=0 || ct.indexOf('entrar')>=0 ||
                       ct.indexOf('ingresar')>=0 || ct.indexOf('submit')>=0 ||
                       ct.indexOf('ok')>=0){
                      click(all[c]); return 'SUBMITTED';
                    }
                  }
                }catch(e){}
              }
              return 'NO_FORM';
            })();
        """.trimIndent()

        web.evaluateJavascript(js) { raw ->
            val r = decodeJsResult(raw)
            when (r) {
                "SUBMITTED" -> {
                    if (sessionRecoveryRunning) {
                        // Login succeeded. Return to the exact MAC Filter page instead
                        // of asking the router menu again (which could create another
                        // redirect and another expired-session race).
                        sessionRecoveryRunning = false
                        loginAttempts = 0
                        val target = macFilterUrl
                        if (!target.isNullOrBlank()) {
                            status.text = "Sesión recuperada ✓"
                            details.text = "Volviendo a MAC Filter para comprobar el cambio."
                            web.postDelayed({ web.loadUrl(target) }, 350)
                        } else {
                            web.postDelayed({ inspectRouterPage() }, 700)
                        }
                    } else {
                        web.postDelayed({ inspectAttempts = 0; inspectRouterPage() }, 1000)
                    }
                }
                else -> {
                    // If the CGI is still building its form, give it another
                    // short attempt without changing the session/navigation.
                    web.postDelayed({ inspectRouterPage() }, 500)
                }
            }
        }
    }

    private fun setButtons(enabled: Boolean) {
        val ok = enabled && !operationRunning
        block.isEnabled = ok
        unblock.isEnabled = ok
    }

    private fun performMacOperation(operation: String) {
        val target = mac.text.toString().trim().uppercase(Locale.US)
        if (!Regex("^[0-9A-F]{2}(:[0-9A-F]{2}){5}$").matches(target)) {
            mac.error = "Usa AA:BB:CC:DD:EE:FF"
            return
        }
        if (!connected || !currentPageLooksLikeMacFilter) {
            status.text = "Primero conecta con el router"
            return
        }
        if (operationRunning) return

        pendingOperation = operation
        pendingMac = target
        operationRunning = true
        operationVerifyAttempts = 0
        setButtons(false)
        status.text = if (operation == "add") "Bloqueando $target…" else "Desbloqueando $target…"
        details.text = "Usando la página MAC Filter del router para aplicar el cambio."

        val escaped = jsQuote(target)
        val add = operation == "add"

        val js = """
            (function(){
              window.__rm_result='RUNNING';
              var MAC=$escaped;
              var ADD=${add};

              function walk(w,out,depth){
                if(depth>8)return;
                try{out.push(w.document);}catch(e){}
                try{for(var i=0;i<w.frames.length;i++)walk(w.frames[i],out,depth+1);}catch(e){}
              }
              function docs(){var a=[];walk(window,a,0);return a;}
              function clean(s){return ((s||'')+'').replace(/\s+/g,' ').trim();}
              function labelOf(e){
                var s='';
                try{s += ' '+clean(e.innerText||e.textContent||e.value||e.title||e.alt);}
                catch(x){}
                try{s += ' '+clean(e.name)+' '+clean(e.id)+' '+clean(e.placeholder)+' '+clean(e.getAttribute('aria-label'));}catch(x){}
                return s.toLowerCase();
              }
              function activate(e){
                if(!e)return false;
                try{e.scrollIntoView({block:'center'});}catch(x){}
                try{e.click();return true;}catch(x){}
                try{
                  var ev=e.ownerDocument.createEvent('MouseEvents');
                  ev.initMouseEvent('click',true,true,e.ownerDocument.defaultView,1,0,0,0,0,false,false,false,false,0,null);
                  e.dispatchEvent(ev); return true;
                }catch(x){}
                return false;
              }
              function findButton(word){
                var ds=docs();
                for(var d=0;d<ds.length;d++){
                  try{
                    var es=ds[d].querySelectorAll('button,input,a,[onclick]');
                    for(var i=0;i<es.length;i++){
                      var t=labelOf(es[i]);
                      if(t===word || t.indexOf(word)>=0) return es[i];
                    }
                  }catch(e){}
                }
                return null;
              }
              function visible(e){
                try{
                  var r=e.getBoundingClientRect(), st=e.ownerDocument.defaultView.getComputedStyle(e);
                  return !!r.width && !!r.height && st.display!=='none' && st.visibility!=='hidden';
                }catch(x){return true;}
              }
              function findMacInput(){
                var names=[
                  'src_macaddress','macfilter_scmac','source_mac','sourcemac',
                  'source_mac_address','srcmac','mac','macaddress','mac_addr','mac_address'
                ];
                var ds=docs();
                // First prefer an editable, visible input inside a table row.
                for(var d=0;d<ds.length;d++){
                  try{
                    var rows=ds[d].querySelectorAll('tr');
                    for(var r=0;r<rows.length;r++){
                      var es=rows[r].querySelectorAll('input[type=text],input:not([type])');
                      for(var j=0;j<es.length;j++){
                        if(!es[j].disabled && visible(es[j])) return es[j];
                      }
                    }
                  }catch(e){}
                }
                for(var d=0;d<ds.length;d++){
                  try{
                    for(var n=0;n<names.length;n++){
                      var e=ds[d].querySelector(
                        'input[name="'+names[n]+'"],input[id="'+names[n]+'"]'
                      );
                      if(e && !e.disabled && visible(e)) return e;
                    }
                    var es=ds[d].querySelectorAll('input[type=text],input:not([type])');
                    for(var i=0;i<es.length;i++){
                      var t=labelOf(es[i]);
                      if(!es[i].disabled && visible(es[i]) &&
                         (t.indexOf('mac')>=0 || t.indexOf('source')>=0)) return es[i];
                    }
                  }catch(e){}
                }
                return null;
              }
              function setValue(e,v){
                if(!e)return false;
                try{
                  var setter=Object.getOwnPropertyDescriptor(
                    e.ownerDocument.defaultView.HTMLInputElement.prototype,'value'
                  );
                  if(setter && setter.set) setter.set.call(e,v); else e.value=v;
                }catch(x){try{e.value=v;}catch(y){}}
                try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(x){}
                try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(x){}
                return ((e.value||'').toUpperCase().replace(/\s/g,'')) ===
                       v.toUpperCase().replace(/\s/g,'');
              }
              function findRow(mac){
                var ds=docs(), wanted=mac.toUpperCase();
                for(var d=0;d<ds.length;d++){
                  try{
                    var rows=ds[d].querySelectorAll('tr');
                    for(var i=0;i<rows.length;i++){
                      var tx=(rows[i].innerText||rows[i].textContent||'').toUpperCase();
                      if(tx.indexOf(wanted)>=0)return rows[i];
                    }
                  }catch(e){}
                }
                return null;
              }
              function findApply(){
                var ds=docs();
                // Prefer the real Apply control, not a menu/link containing the word.
                for(var d=0;d<ds.length;d++){
                  try{
                    var es=ds[d].querySelectorAll('input[type=submit],input[type=button],button');
                    for(var i=0;i<es.length;i++){
                      if(!visible(es[i])) continue;
                      var t=labelOf(es[i]);
                      if(t==='apply' || t==='apply changes' || t.indexOf('apply')===0) return es[i];
                    }
                  }catch(e){}
                }
                for(var d=0;d<ds.length;d++){
                  try{
                    var es=ds[d].querySelectorAll('[onclick],a');
                    for(var i=0;i<es.length;i++){
                      if(!visible(es[i])) continue;
                      var t=labelOf(es[i]);
                      if(t==='apply' || t.indexOf('apply')===0) return es[i];
                    }
                  }catch(e){}
                }
                return null;
              }
              function findDelete(){
                return findButton('delete') || findButton('remove');
              }

              function finish(v){window.__rm_result=v;}

              function addEntry(){
                var input=findMacInput();
                if(!input){
                  var nw=findButton('new');
                  if(nw){activate(nw);setTimeout(addEntry,500);return;}
                  finish('NO_MAC_INPUT');return;
                }
                if(!setValue(input,MAC)){finish('NO_MAC_INPUT');return;}
                setTimeout(function(){
                  var apply=findApply();
                  if(apply){
                    activate(apply);
                    // Do not report success merely because the Apply control was clicked.
                    // The caller will reload the real MAC Filter page and verify the row.
                    finish('APPLY_CLICKED');
                  } else finish('NO_APPLY');
                },450);
              }

              function deleteEntry(){
                var row=findRow(MAC);
                if(!row){finish('NOT_FOUND');return;}

                // Old firmware commonly uses a checkbox in the first column.
                var controls=row.querySelectorAll('input,button,a');
                var selected=false;
                for(var i=0;i<controls.length;i++){
                  var c=controls[i], typ=(c.type||'').toLowerCase();
                  if(typ==='checkbox'){
                    c.checked=true;
                    try{c.dispatchEvent(new Event('change',{bubbles:true}));}catch(x){}
                    selected=true; break;
                  }
                }
                if(!selected){
                  // Some versions put the selection in a radio button.
                  for(var j=0;j<controls.length;j++){
                    var q=controls[j], typ2=(q.type||'').toLowerCase();
                    if(typ2==='radio'){q.checked=true;selected=true;break;}
                  }
                }
                var del=findDelete();
                if(del){
                  activate(del);
                  setTimeout(function(){
                    var apply=findApply();
                    if(apply){activate(apply);finish('DELETE_APPLY_CLICKED');}
                    else finish('NO_APPLY');
                  },500);
                }else{
                  finish('NO_DELETE');
                }
              }

              if(ADD){
                var nw=findButton('new');
                if(nw){
                  activate(nw);
                  setTimeout(addEntry,550);
                }else{
                  // Some firmwares already show an empty editable row.
                  addEntry();
                }
              }else{
                deleteEntry();
              }
              return 'RUNNING';
            })();
        """.trimIndent()

        web.evaluateJavascript(js) {
            web.postDelayed({ pollOperationResult() }, 500)
        }
    }

    private fun verifyOperationAfterNavigation() {
        operationVerifyAttempts++
        val wanted = pendingMac ?: run {
            operationRunning = false
            setButtons(connected)
            return
        }
        val add = pendingOperation == "add"
        val escaped = jsQuote(wanted)

        val js = """
            (function(){
              var MAC=$escaped;
              function walk(w,out,depth){
                if(depth>8)return;
                try{out.push(w.document);}catch(e){}
                try{for(var i=0;i<w.frames.length;i++)walk(w.frames[i],out,depth+1);}catch(e){}
              }
              var ds=[];walk(window,ds,0);
              var found=false, page=false, count=-1;
              for(var d=0;d<ds.length;d++){
                try{
                  var tx=((ds[d].body&&ds[d].body.innerText)||'').toUpperCase();
                  if(tx.indexOf('MAC FILTER')>=0 || tx.indexOf('SOURCE MAC ADDRESS')>=0) page=true;
                  if(tx.indexOf(MAC.toUpperCase())>=0) found=true;
                  var m=tx.match(/CURRENT ENTRY NUMBER\s*:\s*(\d+)/i);
                  if(m) count=parseInt(m[1],10);
                }catch(e){}
              }
              return (page?'PAGE':'NOPAGE')+':'+(found?'FOUND':'ABSENT')+':COUNT='+count;
            })();
        """.trimIndent()

        web.evaluateJavascript(js) { raw ->
            val r = decodeJsResult(raw)
            val success = if (add) r.contains(":FOUND:COUNT=") else r.contains(":ABSENT:COUNT=")
            if (success) {
                operationRunning = false
                connected = r.startsWith("PAGE")
                currentPageLooksLikeMacFilter = connected
                setButtons(connected)
                if (add) {
                    status.text = "MAC bloqueada ✓"
                    details.text = "El router confirmó la entrada en MAC Filter."
                } else {
                    status.text = "MAC desbloqueada ✓"
                    details.text = "El router ya no muestra esa MAC en la lista."
                }
            } else {
                web.postDelayed({
                    web.evaluateJavascript("document.body && document.body.innerText || ''") { again ->
                        val text = decodeJsResult(again).uppercase(Locale.US)
                        val found = text.contains(wanted.uppercase(Locale.US))
                        val page = text.contains("MAC FILTER") || text.contains("SOURCE MAC ADDRESS")
                        val done = if (add) found else page && !found
                        if (done) {
                            operationRunning = false
                            connected = page
                            currentPageLooksLikeMacFilter = page
                            setButtons(page)
                            status.text = if (add) "MAC bloqueada ✓" else "MAC desbloqueada ✓"
                            details.text = "Cambio confirmado en la página del router."
                        } else if (operationVerifyAttempts < 10) {
                            // Give the old CGI a little more time to finish.
                            web.postDelayed({ verifyOperationAfterNavigation() }, 700)
                        } else {
                            operationRunning = false
                            setButtons(connected)
                            status.text = "El router no confirmó el cambio"
                            details.text = "La página respondió, pero no pude verificar que la MAC cambiara."
                        }
                    }
                }, 700)
            }
        }
    }

    private fun pollOperationResult() {
        web.evaluateJavascript("window.__rm_result || 'RUNNING'") { raw ->
            val r = decodeJsResult(raw)
            when (r) {
                "RUNNING" -> web.postDelayed({ pollOperationResult() }, 350)
                "APPLY_CLICKED", "DELETE_APPLY_CLICKED" -> {
                    // The router can accept the click without committing the row yet.
                    // Force a fresh read of the actual MAC Filter page and verify the
                    // persisted table before telling the user that it worked.
                    details.text = "Apply pulsado. Comprobando que el router guardó el cambio…"
                    web.postDelayed({
                        operationVerifyAttempts = 0
                        inspectOperationPage()
                    }, 1200)
                }
                "NO_MAC_INPUT" -> {
                    operationRunning = false
                    setButtons(connected)
                    status.text = "No encontré el campo Source MAC"
                    details.text = "El firmware usa otra estructura para el campo de MAC."
                }
                "NOT_FOUND" -> {
                    operationRunning = false
                    setButtons(connected)
                    status.text = "Esa MAC no está en la lista"
                    details.text = "No encontré $pendingMac entre las entradas actuales."
                }
                "NO_DELETE" -> {
                    operationRunning = false
                    setButtons(connected)
                    status.text = "No encontré cómo eliminar esa MAC"
                    details.text = "La entrada existe, pero este firmware no mostró un control Delete utilizable."
                }
                "NO_APPLY" -> {
                    operationRunning = false
                    setButtons(connected)
                    status.text = "No encontré el botón Apply"
                    details.text = "La orden se preparó, pero no apareció el botón para guardar el cambio."
                }
                else -> {
                    // Unknown JS result: keep the operation conservative and verify once.
                    details.text = "Comprobando el estado real del filtro…"
                    web.postDelayed({
                        operationVerifyAttempts = 0
                        inspectOperationPage()
                    }, 700)
                }
            }
        }
    }

    private fun decodeJsResult(raw: String): String {
        if (raw == "null") return ""
        return raw
            .removePrefix("\"")
            .removeSuffix("\"")
            .replace("\\n", "\n")
            .replace("\\\"", "\"")
            .replace("\\/", "/")
            .replace("\\\\", "\\")
    }

    private fun jsQuote(value: String): String {
        return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"
    }

    override fun onDestroy() {
        try { web.stopLoading(); web.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }
}
