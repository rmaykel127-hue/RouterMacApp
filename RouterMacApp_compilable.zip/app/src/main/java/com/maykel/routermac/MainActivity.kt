package com.maykel.routermac

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {
    companion object {
        private const val ROUTER_USER = "admin"
        private const val ROUTER_PASSWORD = "system"
    }

    private lateinit var ip: EditText
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var block: Button
    private lateinit var unblock: Button
    private lateinit var mac: EditText
    private lateinit var web: WebView

    private var connected = false
    private var currentBase = "http://192.168.1.1"
    private var currentPageLooksLikeMacFilter = false
    private var operationRunning = false
    private var pendingOperation: String? = null
    private var pendingMac: String? = null
    private var inspectAttempts = 0
    private var loginAttempts = 0
    private var operationVerifyAttempts = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ip = findViewById(R.id.routerIp)
        status = findViewById(R.id.status)
        details = findViewById(R.id.details)
        block = findViewById(R.id.block)
        unblock = findViewById(R.id.unblock)
        mac = findViewById(R.id.mac)
        web = findViewById(R.id.routerWeb)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        web.settings.allowFileAccess = true
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                val m = (message ?: "").lowercase(Locale.US)
                // Some old router CGI versions signal a missing login password
                // with JavaScript alert() instead of rendering a login form.
                // Do not leave the user stuck at that dialog: retry the automatic
                // login against the same WebView/session.
                if (m.contains("password") || m.contains("contraseña") ||
                    m.contains("passwd") || m.contains("pass word")) {
                    result?.cancel()
                    view?.postDelayed({ autoLogin() }, 150)
                    return true
                }
                return super.onJsAlert(view, url, message, result)
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun onReceivedHttpAuthRequest(
                view: WebView?,
                handler: android.webkit.HttpAuthHandler?,
                host: String?,
                realm: String?
            ) {
                // Some firmware revisions protect the CGI with HTTP Basic/Digest
                // authentication instead of a normal HTML login form. Use the
                // router credentials supplied for this app automatically.
                handler?.proceed(ROUTER_USER, ROUTER_PASSWORD)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                inspectAttempts = 0
                if (operationRunning && pendingOperation != null) {
                    // Apply/Delete can reload the CGI page. In that case the
                    // JavaScript context is replaced, so verify the result
                    // from the freshly loaded page instead of relying on a
                    // sessionkey or a JS variable surviving navigation.
                    view?.postDelayed({ verifyOperationAfterNavigation() }, 350)
                } else {
                    view?.postDelayed({ inspectRouterPage() }, 250)
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                // Keep every CGI navigation inside the same WebView so the
                // router's own cookies/session state are never lost.
                return false
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        findViewById<Button>(R.id.connect).setOnClickListener { connect() }
        block.setOnClickListener { performMacOperation("add") }
        unblock.setOnClickListener { performMacOperation("delete") }
        setButtons(false)
    }

    private fun baseUrl(): String {
        var host = ip.text.toString().trim()
        if (host.isBlank()) host = "192.168.1.1"
        host = host.removePrefix("http://").removePrefix("https://")
        host = host.substringBefore('/').trim().trimEnd('/')
        return "http://$host"
    }

    private fun connect() {
        currentBase = baseUrl()
        connected = false
        currentPageLooksLikeMacFilter = false
        operationRunning = false
        inspectAttempts = 0
        loginAttempts = 0
        setButtons(false)
        status.text = "Conectando al router…"
        details.text = "Abriendo la interfaz CGI del router y buscando MAC Filter."
        web.loadUrl("$currentBase/cgi-bin/login.cgi")
    }

    private fun inspectRouterPage() {
        if (operationRunning) return

        val js = """
            (function(){
              function walk(w, out, depth){
                if(depth > 8) return;
                try { out.push(w.document); } catch(e) {}
                try {
                  for(var i=0;i<w.frames.length;i++) walk(w.frames[i],out,depth+1);
                } catch(e){}
              }
              function textOf(e){
                return (((e.innerText||e.value||e.textContent||e.title||e.alt||'')+'')
                  .replace(/\s+/g,' ').trim());
              }
              function hrefOf(e){ try{return (e.getAttribute('href')||'').trim();}catch(x){return '';} }

              var ds=[]; walk(window,ds,0);
              var allText='';
              var bestHref=null;
              for(var d=0;d<ds.length;d++){
                try{
                  allText += ' ' + (ds[d].body ? ds[d].body.innerText : '');
                  var els=ds[d].querySelectorAll('a,button,input,area,[onclick]');
                  for(var i=0;i<els.length;i++){
                    var e=els[i], t=textOf(e), h=hrefOf(e);
                    var s=(t+' '+h).toLowerCase();
                    if(s.indexOf('mac filter')>=0 || s.indexOf('mac_filter')>=0 ||
                       s.indexOf('macfilter')>=0){
                      bestHref=h || null;
                      try{ e.scrollIntoView(); }catch(x){}
                      // Do not depend on synthetic click for old firmware.
                      if(h && h !== '#' && !/^javascript:/i.test(h)){
                        return 'MAC_HREF:'+h;
                      }
                      try{ e.click(); return 'MAC_CLICKED'; }catch(x){}
                    }
                  }
                }catch(e){}
              }

              var lower=allText.toLowerCase();
              if(lower.indexOf('source mac address')>=0 ||
                 lower.indexOf('mac filter enable')>=0 ||
                 lower.indexOf('current entry number')>=0){
                return 'MAC_PAGE';
              }
              if(lower.indexOf('need_login')>=0 || lower.indexOf('login')>=0 ||
                 lower.indexOf('password')>=0 || lower.indexOf('username')>=0){
                return 'LOGIN_PAGE';
              }
              return 'OTHER';
            })();
        """.trimIndent()

        web.evaluateJavascript(js) { raw ->
            val r = decodeJsResult(raw)
            when {
                r == "MAC_PAGE" -> {
                    connected = true
                    currentPageLooksLikeMacFilter = true
                    status.text = "Router conectado ✓"
                    details.text = "MAC Filter encontrada. Los botones están listos."
                    setButtons(true)
                }

                r.startsWith("MAC_HREF:") -> {
                    val href = r.removePrefix("MAC_HREF:")
                    connected = false
                    currentPageLooksLikeMacFilter = false
                    status.text = "Abriendo MAC Filter…"
                    details.text = "Encontré la página MAC Filter en el menú del router."
                    setButtons(false)
                    val target = when {
                        href.startsWith("http://") || href.startsWith("https://") -> href
                        href.startsWith("/") -> "$currentBase$href"
                        else -> "$currentBase/$href"
                    }
                    web.post { web.loadUrl(target) }
                }

                r == "MAC_CLICKED" -> {
                    connected = false
                    currentPageLooksLikeMacFilter = false
                    status.text = "Abriendo MAC Filter…"
                    details.text = "Encontré MAC Filter en el menú del router."
                    setButtons(false)
                    web.postDelayed({ inspectRouterPage() }, 700)
                }

                else -> {
                    if (inspectAttempts < 8) {
                        inspectAttempts++
                        web.postDelayed({ inspectRouterPage() }, 600)
                    } else {
                        connected = false
                        currentPageLooksLikeMacFilter = false
                        setButtons(false)
                        if (r == "LOGIN_PAGE") {
                            if (loginAttempts < 3) {
                                loginAttempts++
                                status.text = "Iniciando sesión en el router…"
                                details.text = "Usando las credenciales del router y manteniendo la misma sesión CGI."
                                autoLogin()
                            } else {
                                status.text = "El router pide iniciar sesión"
                                details.text = "No pude completar automáticamente el inicio de sesión con las credenciales configuradas."
                            }
                        } else {
                            status.text = "Router conectado, pero no encontré MAC Filter"
                            details.text = "La interfaz respondió, pero la página MAC Filter todavía no fue localizada."
                        }
                    }
                }
            }
        }
    }

    private fun autoLogin() {
        val user = jsQuote(ROUTER_USER)
        val pass = jsQuote(ROUTER_PASSWORD)
        val js = """
            (function(){
              var USER=$user, PASS=$pass;
              function walk(w,out,depth){
                if(depth>8)return;
                try{out.push(w.document);}catch(e){}
                try{for(var i=0;i<w.frames.length;i++)walk(w.frames[i],out,depth+1);}catch(e){}
              }
              function clean(s){return ((s||'')+'').replace(/\s+/g,' ').trim().toLowerCase();}
              function label(e){
                var s='';
                try{s+=' '+clean(e.name)+' '+clean(e.id)+' '+clean(e.placeholder)+' '+clean(e.title)+' '+clean(e.getAttribute('aria-label'));}catch(x){}
                try{
                  if(e.labels) for(var i=0;i<e.labels.length;i++) s+=' '+clean(e.labels[i].innerText||e.labels[i].textContent);
                }catch(x){}
                return s;
              }
              function setv(e,v){
                try{
                  var p=e.ownerDocument.defaultView.HTMLInputElement.prototype;
                  var d=Object.getOwnPropertyDescriptor(p,'value');
                  if(d&&d.set)d.set.call(e,v);else e.value=v;
                }catch(x){try{e.value=v;}catch(y){}}
                try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(x){}
                try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(x){}
              }
              function click(e){
                try{e.click();return true;}catch(x){}
                try{
                  var ev=e.ownerDocument.createEvent('MouseEvents');
                  ev.initMouseEvent('click',true,true,e.ownerDocument.defaultView,1,0,0,0,0,false,false,false,false,0,null);
                  e.dispatchEvent(ev);return true;
                }catch(x){}
                return false;
              }
              var ds=[];walk(window,ds,0);
              for(var d=0;d<ds.length;d++){
                try{
                  var doc=ds[d], inputs=doc.querySelectorAll('input,textarea');
                  var pw=null, un=null;
                  for(var i=0;i<inputs.length;i++){
                    var e=inputs[i], typ=(e.type||'').toLowerCase(), l=label(e);
                    if(!pw && (typ==='password' || l.indexOf('password')>=0 || l.indexOf('passwd')>=0 || l.indexOf('pwd')>=0 || l.indexOf('psw')>=0 || l.indexOf('pass')>=0)) pw=e;
                  }
                  if(!pw) continue;
                  for(var j=0;j<inputs.length;j++){
                    var q=inputs[j], qt=(q.type||'').toLowerCase(), ql=label(q);
                    if(q===pw || qt==='password' || qt==='hidden') continue;
                    if(qt==='text' || qt==='email' || qt==='tel' || qt===''){
                      if(ql.indexOf('user')>=0 || ql.indexOf('userid')>=0 || ql.indexOf('username')>=0 || ql.indexOf('login')>=0 || ql.indexOf('account')>=0 || ql.indexOf('name')>=0){un=q;break;}
                    }
                  }
                  if(!un){
                    for(var k=0;k<inputs.length;k++){
                      var z=inputs[k], zt=(z.type||'').toLowerCase();
                      if(zt==='text' || zt==='email'){un=z;break;}
                    }
                  }
                  if(un) setv(un,USER);
                  setv(pw,PASS);
                  var passValue='';
                  try{passValue=(pw.value||'')+'';}catch(x){}
                  if(passValue !== PASS){
                    return 'NO_PASSWORD_FIELD';
                  }

                  var form=pw.form;
                  if(form){
                    var btns=form.querySelectorAll('input[type=submit],input[type=button],button,a');
                    for(var b=0;b<btns.length;b++){
                      var bt=clean(btns[b].value||btns[b].innerText||btns[b].textContent||btns[b].title);
                      if(bt.indexOf('login')>=0 || bt.indexOf('sign in')>=0 || bt.indexOf('entrar')>=0 || bt.indexOf('ingresar')>=0 || bt.indexOf('ok')>=0){
                        click(btns[b]); return 'SUBMITTED';
                      }
                    }
                    try{HTMLFormElement.prototype.submit.call(form);return 'SUBMITTED';}catch(x){}
                  }
                  var all=doc.querySelectorAll('input[type=submit],input[type=button],button');
                  for(var c=0;c<all.length;c++){
                    var ct=clean(all[c].value||all[c].innerText||all[c].textContent||all[c].title);
                    if(ct.indexOf('login')>=0 || ct.indexOf('entrar')>=0 || ct.indexOf('ingresar')>=0 || ct==='ok'){click(all[c]);return 'SUBMITTED';}
                  }
                }catch(e){}
              }
              return 'NO_FORM';
            })();
        """.trimIndent()
        web.evaluateJavascript(js) { raw ->
            val r = decodeJsResult(raw)
            when (r) {
                "SUBMITTED" -> web.postDelayed({ inspectRouterPage() }, 1200)
                "NO_PASSWORD_FIELD" -> {
                    status.text = "No pude completar el campo de contraseña"
                    details.text = "El router usa un formulario CGI distinto; no se envió una contraseña vacía."
                    web.postDelayed({ inspectRouterPage() }, 700)
                }
                else -> web.postDelayed({ inspectRouterPage() }, 500)
            }
        }
    }

    private fun setButtons(enabled: Boolean) {
        val ok = enabled && !operationRunning
        block.isEnabled = ok
        unblock.isEnabled = ok
    }

    private fun performMacOperation(operation: String) {
        val target = mac.text.toString().trim().uppercase(Locale.US)
        if (!Regex("^[0-9A-F]{2}(:[0-9A-F]{2}){5}$").matches(target)) {
            mac.error = "Usa AA:BB:CC:DD:EE:FF"
            return
        }
        if (!connected || !currentPageLooksLikeMacFilter) {
            status.text = "Primero conecta con el router"
            return
        }
        if (operationRunning) return

        pendingOperation = operation
        pendingMac = target
        operationRunning = true
        operationVerifyAttempts = 0
        setButtons(false)
        status.text = if (operation == "add") "Bloqueando $target…" else "Desbloqueando $target…"
        details.text = "Usando la página MAC Filter del router para aplicar el cambio."

        val escaped = jsQuote(target)
        val add = operation == "add"

        val js = """
            (function(){
              window.__rm_result='RUNNING';
              var MAC=$escaped;
              var ADD=${add};

              function walk(w,out,depth){
                if(depth>8)return;
                try{out.push(w.document);}catch(e){}
                try{for(var i=0;i<w.frames.length;i++)walk(w.frames[i],out,depth+1);}catch(e){}
              }
              function docs(){var a=[];walk(window,a,0);return a;}
              function clean(s){return ((s||'')+'').replace(/\s+/g,' ').trim();}
              function labelOf(e){
                var s='';
                try{s += ' '+clean(e.innerText||e.textContent||e.value||e.title||e.alt);}
                catch(x){}
                try{s += ' '+clean(e.name)+' '+clean(e.id)+' '+clean(e.placeholder)+' '+clean(e.getAttribute('aria-label'));}catch(x){}
                return s.toLowerCase();
              }
              function activate(e){
                if(!e)return false;
                try{e.scrollIntoView({block:'center'});}catch(x){}
                try{e.click();return true;}catch(x){}
                try{
                  var ev=e.ownerDocument.createEvent('MouseEvents');
                  ev.initMouseEvent('click',true,true,e.ownerDocument.defaultView,1,0,0,0,0,false,false,false,false,0,null);
                  e.dispatchEvent(ev); return true;
                }catch(x){}
                return false;
              }
              function findButton(word){
                var ds=docs();
                for(var d=0;d<ds.length;d++){
                  try{
                    var es=ds[d].querySelectorAll('button,input,a,[onclick]');
                    for(var i=0;i<es.length;i++){
                      var t=labelOf(es[i]);
                      if(t===word || t.indexOf(word)>=0) return es[i];
                    }
                  }catch(e){}
                }
                return null;
              }
              function findMacInput(){
                var names=[
                  'src_macaddress','macfilter_scmac','source_mac','sourcemac',
                  'source_mac_address','srcmac','mac','macaddress','mac_addr','mac_address'
                ];
                var ds=docs();
                for(var d=0;d<ds.length;d++){
                  try{
                    for(var n=0;n<names.length;n++){
                      var e=ds[d].querySelector(
                        'input[name="'+names[n]+'"],input[id="'+names[n]+'"]'
                      );
                      if(e && !e.disabled) return e;
                    }
                    var es=ds[d].querySelectorAll('input[type=text],input:not([type])');
                    for(var i=0;i<es.length;i++){
                      var t=labelOf(es[i]);
                      if(t.indexOf('mac')>=0 || t.indexOf('source')>=0) return es[i];
                    }
                  }catch(e){}
                }
                return null;
              }
              function setValue(e,v){
                if(!e)return false;
                try{
                  var setter=Object.getOwnPropertyDescriptor(
                    e.ownerDocument.defaultView.HTMLInputElement.prototype,'value'
                  );
                  if(setter && setter.set) setter.set.call(e,v); else e.value=v;
                }catch(x){try{e.value=v;}catch(y){}}
                try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(x){}
                try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(x){}
                return ((e.value||'').toUpperCase().replace(/\s/g,'')) ===
                       v.toUpperCase().replace(/\s/g,'');
              }
              function findRow(mac){
                var ds=docs(), wanted=mac.toUpperCase();
                for(var d=0;d<ds.length;d++){
                  try{
                    var rows=ds[d].querySelectorAll('tr');
                    for(var i=0;i<rows.length;i++){
                      var tx=(rows[i].innerText||rows[i].textContent||'').toUpperCase();
                      if(tx.indexOf(wanted)>=0)return rows[i];
                    }
                  }catch(e){}
                }
                return null;
              }
              function findApply(){
                var ds=docs();
                var words=['apply','save','submit'];
                for(var d=0;d<ds.length;d++){
                  try{
                    var es=ds[d].querySelectorAll(
                      'input[type=submit],input[type=button],button,a,[onclick]'
                    );
                    for(var i=0;i<es.length;i++){
                      var e=es[i];
                      var t=labelOf(e);
                      var v='';
                      try{v=clean(e.value||e.getAttribute('value')||'').toLowerCase();}catch(x){}
                      var n='';
                      try{n=clean(e.name||e.id||'').toLowerCase();}catch(x){}
                      var all=(t+' '+v+' '+n).replace(/\s+/g,' ').trim();
                      if(words.some(function(w){return all===w || all.indexOf(w)>=0;})) return e;
                    }
                  }catch(e){}
                }
                return null;
              }
              function findDelete(){
                return findButton('delete') || findButton('remove');
              }

              function finish(v){window.__rm_result=v;}

              function addEntry(){
                var input=findMacInput();
                if(!input){
                  var nw=findButton('new');
                  if(nw){activate(nw);setTimeout(addEntry,500);return;}
                  finish('NO_MAC_INPUT');return;
                }
                if(!setValue(input,MAC)){finish('NO_MAC_INPUT');return;}
                var tries=0;
                function waitForApply(){
                  var apply=findApply();
                  if(apply){
                    activate(apply);
                    finish('ADD_SENT');
                    return;
                  }
                  tries++;
                  if(tries<12){
                    setTimeout(waitForApply,500);
                  }else{
                    finish('NO_APPLY');
                  }
                }
                setTimeout(waitForApply,350);
              }

              function deleteEntry(){
                var row=findRow(MAC);
                if(!row){finish('NOT_FOUND');return;}

                // Old firmware commonly uses a checkbox in the first column.
                var controls=row.querySelectorAll('input,button,a');
                var selected=false;
                for(var i=0;i<controls.length;i++){
                  var c=controls[i], typ=(c.type||'').toLowerCase();
                  if(typ==='checkbox'){
                    c.checked=true;
                    try{c.dispatchEvent(new Event('change',{bubbles:true}));}catch(x){}
                    selected=true; break;
                  }
                }
                if(!selected){
                  // Some versions put the selection in a radio button.
                  for(var j=0;j<controls.length;j++){
                    var q=controls[j], typ2=(q.type||'').toLowerCase();
                    if(typ2==='radio'){q.checked=true;selected=true;break;}
                  }
                }
                var del=findDelete();
                if(del){
                  activate(del);
                  var tries=0;
                  function waitForApply(){
                    var apply=findApply();
                    if(apply){
                      activate(apply);
                      finish('DELETE_SENT');
                      return;
                    }
                    tries++;
                    if(tries<12){
                      setTimeout(waitForApply,500);
                    }else{
                      finish('NO_APPLY');
                    }
                  }
                  setTimeout(waitForApply,350);
                }else{
                  finish('NO_DELETE');
                }
              }

              if(ADD){
                var nw=findButton('new');
                if(nw){
                  activate(nw);
                  setTimeout(addEntry,550);
                }else{
                  // Some firmwares already show an empty editable row.
                  addEntry();
                }
              }else{
                deleteEntry();
              }
              return 'RUNNING';
            })();
        """.trimIndent()

        web.evaluateJavascript(js) {
            web.postDelayed({ pollOperationResult() }, 500)
        }
    }

    private fun verifyOperationAfterNavigation() {
        operationVerifyAttempts++
        val wanted = pendingMac ?: run {
            operationRunning = false
            setButtons(connected)
            return
        }
        val add = pendingOperation == "add"
        val escaped = jsQuote(wanted)

        val js = """
            (function(){
              var MAC=$escaped;
              function walk(w,out,depth){
                if(depth>8)return;
                try{out.push(w.document);}catch(e){}
                try{for(var i=0;i<w.frames.length;i++)walk(w.frames[i],out,depth+1);}catch(e){}
              }
              var ds=[];walk(window,ds,0);
              var found=false, page=false;
              for(var d=0;d<ds.length;d++){
                try{
                  var tx=((ds[d].body&&ds[d].body.innerText)||'').toUpperCase();
                  if(tx.indexOf('MAC FILTER')>=0 || tx.indexOf('SOURCE MAC ADDRESS')>=0) page=true;
                  if(tx.indexOf(MAC.toUpperCase())>=0) found=true;
                }catch(e){}
              }
              return (page?'PAGE':'NOPAGE')+':'+(found?'FOUND':'ABSENT');
            })();
        """.trimIndent()

        web.evaluateJavascript(js) { raw ->
            val r = decodeJsResult(raw)
            val success = if (add) r.endsWith(":FOUND") else r.endsWith(":ABSENT")
            if (success) {
                operationRunning = false
                connected = r.startsWith("PAGE")
                currentPageLooksLikeMacFilter = connected
                setButtons(connected)
                if (add) {
                    status.text = "MAC bloqueada ✓"
                    details.text = "El router confirmó la entrada en MAC Filter."
                } else {
                    status.text = "MAC desbloqueada ✓"
                    details.text = "El router ya no muestra esa MAC en la lista."
                }
            } else {
                web.postDelayed({
                    web.evaluateJavascript("document.body && document.body.innerText || ''") { again ->
                        val text = decodeJsResult(again).uppercase(Locale.US)
                        val found = text.contains(wanted.uppercase(Locale.US))
                        val page = text.contains("MAC FILTER") || text.contains("SOURCE MAC ADDRESS")
                        val done = if (add) found else page && !found
                        if (done) {
                            operationRunning = false
                            connected = page
                            currentPageLooksLikeMacFilter = page
                            setButtons(page)
                            status.text = if (add) "MAC bloqueada ✓" else "MAC desbloqueada ✓"
                            details.text = "Cambio confirmado en la página del router."
                        } else if (operationVerifyAttempts < 10) {
                            // Give the old CGI a little more time to finish.
                            web.postDelayed({ verifyOperationAfterNavigation() }, 700)
                        } else {
                            operationRunning = false
                            setButtons(connected)
                            status.text = "El router no confirmó el cambio"
                            details.text = "La página respondió, pero no pude verificar que la MAC cambiara."
                        }
                    }
                }, 700)
            }
        }
    }

    private fun pollOperationResult() {
        web.evaluateJavascript("window.__rm_result || 'RUNNING'") { raw ->
            val r = decodeJsResult(raw)
            if (r == "RUNNING" || r.isBlank()) {
                web.postDelayed({ pollOperationResult() }, 500)
                return@evaluateJavascript
            }

            operationRunning = false
            setButtons(connected)

            when (r) {
                "ADD_SENT" -> {
                    status.text = "MAC bloqueada ✓"
                    details.text = "La orden se envió desde la página MAC Filter del router."
                }
                "DELETE_SENT" -> {
                    status.text = "MAC desbloqueada ✓"
                    details.text = "La entrada se eliminó y se aplicó el cambio en el router."
                }
                "NOT_FOUND" -> {
                    status.text = "Esa MAC no está en la lista"
                    details.text = "No encontré $pendingMac entre las entradas actuales."
                }
                "NO_MAC_INPUT" -> {
                    status.text = "No encontré el campo Source MAC"
                    details.text = "El firmware usa otra estructura para el campo de MAC."
                }
                "NO_DELETE" -> {
                    status.text = "No encontré cómo eliminar esa MAC"
                    details.text = "La entrada existe, pero este firmware no mostró un control Delete utilizable."
                }
                "NO_APPLY" -> {
                    status.text = "No encontré el botón Apply"
                    details.text = "La orden se preparó, pero no apareció el botón para guardar el cambio."
                }
                else -> {
                    status.text = "No se pudo completar la operación"
                    details.text = r
                }
            }
        }
    }

    private fun decodeJsResult(raw: String): String {
        if (raw == "null") return ""
        return raw
            .removePrefix("\"")
            .removeSuffix("\"")
            .replace("\\n", "\n")
            .replace("\\\"", "\"")
            .replace("\\/", "/")
            .replace("\\\\", "\\")
    }

    private fun jsQuote(value: String): String {
        return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"
    }

    override fun onDestroy() {
        try { web.stopLoading(); web.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }
}
