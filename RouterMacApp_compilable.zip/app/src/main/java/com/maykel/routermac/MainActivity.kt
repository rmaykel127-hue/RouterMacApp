package com.maykel.routermac

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {
    companion object {
        private const val ROUTER_USER = "admin"
        private const val ROUTER_PASSWORD = "system"
    }

    private lateinit var ip: EditText
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var block: Button
    private lateinit var unblock: Button
    private lateinit var mac: EditText
    private lateinit var web: WebView

    private var connected = false
    private var currentBase = "http://192.168.1.1"
    private var currentPageLooksLikeMacFilter = false
    private var operationRunning = false
    private var pendingOperation: String? = null
    private var pendingMac: String? = null
    private var inspectAttempts = 0
    private var loginAttempts = 0
    private var operationVerifyAttempts = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ip = findViewById(R.id.routerIp)
        status = findViewById(R.id.status)
        details = findViewById(R.id.details)
        block = findViewById(R.id.block)
        unblock = findViewById(R.id.unblock)
        mac = findViewById(R.id.mac)
        web = findViewById(R.id.routerWeb)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        web.settings.allowFileAccess = true
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: android.webkit.JsResult?
            ): Boolean {
                val m = (message ?: "").lowercase(Locale.US)
                // Some old router CGI versions signal a missing login password
                // with JavaScript alert() instead of rendering a login form.
                // Do not leave the user stuck at that dialog: retry the automatic
                // login against the same WebView/session.
                if (m.contains("password") || m.contains("contraseña") ||
                    m.contains("passwd") || m.contains("pass word")) {
                    result?.cancel()
                    view?.postDelayed({ autoLogin() }, 150)
                    return true
                }
                return super.onJsAlert(view, url, message, result)
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun onReceivedHttpAuthRequest(
                view: WebView?,
                handler: android.webkit.HttpAuthHandler?,
                host: String?,
                realm: String?
            ) {
                // Some firmware revisions protect the CGI with HTTP Basic/Digest
                // authentication instead of a normal HTML login form. Use the
                // router credentials supplied for this app automatically.
                handler?.proceed(ROUTER_USER, ROUTER_PASSWORD)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                inspectAttempts = 0
                if (operationRunning && pendingOperation != null) {
                    // Apply/Delete can reload the CGI page. In that case the
                    // JavaScript context is replaced, so verify the result
                    // from the freshly loaded page instead of relying on a
                    // sessionkey or a JS variable surviving navigation.
                    view?.postDelayed({ verifyOperationAfterNavigation() }, 350)
                } else {
                    view?.postDelayed({ inspectRouterPage() }, 250)
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                // Keep every CGI navigation inside the same WebView so the
                // router's own cookies/session state are never lost.
                return false
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        findViewById<Button>(R.id.connect).setOnClickListener { connect() }
        block.setOnClickListener { performMacOperation("add") }
        unblock.setOnClickListener { performMacOperation("delete") }
        setButtons(false)
    }

    private fun baseUrl(): String {
        var host = ip.text.toString().trim()
        if (host.isBlank()) host = "192.168.1.1"
        host = host.removePrefix("http://").removePrefix("https://")
        host = host.substringBefore('/').trim().trimEnd('/')
        return "http://$host"
    }

    private fun connect() {
        currentBase = baseUrl()
        connected = false
        currentPageLooksLikeMacFilter = false
        operationRunning = false
        inspectAttempts = 0
        loginAttempts = 0
        setButtons(false)
        status.text = "Conectando al router…"
        details.text = "Abriendo la interfaz CGI del router y buscando MAC Filter."
        web.loadUrl("$currentBase/cgi-bin/login.cgi")
    }

    private fun inspectRouterPage() {
        if (operationRunning) return

        val js = """
            (function(){
              function walk(w, out, depth){
                if(depth > 8) return;
                try { out.push(w.document); } catch(e) {}
                try {
                  for(var i=0;i<w.frames.length;i++) walk(w.frames[i],out,depth+1);
                } catch(e){}
              }
              function textOf(e){
                return (((e.innerText||e.value||e.textContent||e.title||e.alt||'')+'')
                  .replace(/\s+/g,' ').trim());
              }
              function hrefOf(e){ try{return (e.getAttribute('href')||'').trim();}catch(x){return '';} }

              var ds=[]; walk(window,ds,0);
              var allText='';
              var bestHref=null;
              for(var d=0;d<ds.length;d++){
                try{
                  allText += ' ' + (ds[d].body ? ds[d].body.innerText : '');
                  var els=ds[d].querySelectorAll('a,button,input,area,[onclick]');
                  for(var i=0;i<els.length;i++){
                    var e=els[i], t=textOf(e), h=hrefOf(e);
                    var s=(t+' '+h).toLowerCase();
                    if(s.indexOf('mac filter')>=0 || s.indexOf('mac_filter')>=0 ||
                       s.indexOf('macfilter')>=0){
                      bestHref=h || null;
                      try{ e.scrollIntoView(); }catch(x){}
                      // Do not depend on synthetic click for old firmware.
                      if(h && h !== '#' && !/^javascript:/i.test(h)){
                        return 'MAC_HREF:'+h;
                      }
                      try{ e.click(); return 'MAC_CLICKED'; }catch(x){}
                    }
                  }
                }catch(e){}
              }

              var lower=allText.toLowerCase();
              if(lower.indexOf('source mac address')>=0 ||
                 lower.indexOf('mac filter enable')>=0 ||
                 lower.indexOf('current entry number')>=0){
                return 'MAC_PAGE';
              }
              if(lower.indexOf('need_login')>=0 || lower.indexOf('login')>=0 ||
                 lower.indexOf('password')>=0 || lower.indexOf('username')>=0){
                return 'LOGIN_PAGE';
              }
              return 'OTHER';
            })();
        """.trimIndent()

        web.evaluateJavascript(js) { raw ->
            val r = decodeJsResult(raw)
            when {
                r == "MAC_PAGE" -> {
                    connected = true
                    currentPageLooksLikeMacFilter = true
                    status.text = "Router conectado ✓"
                    details.text = "MAC Filter encontrada. Los botones están listos."
                    setButtons(true)
                }

                r.startsWith("MAC_HREF:") -> {
                    val href = r.removePrefix("MAC_HREF:")
                    connected = false
                    currentPageLooksLikeMacFilter = false
                    status.text = "Abriendo MAC Filter…"
                    details.text = "Encontré la página MAC Filter en el menú del router."
                    setButtons(false)
                    val target = when {
                        href.startsWith("http://") || href.startsWith("https://") -> href
                        href.startsWith("/") -> "$currentBase$href"
                        else -> "$currentBase/$href"
                    }
                    web.post { web.loadUrl(target) }
                }

                r == "MAC_CLICKED" -> {
                    connected = false
                    currentPageLooksLikeMacFilter = false
                    status.text = "Abriendo MAC Filter…"
                    details.text = "Encontré MAC Filter en el menú del router."
                    setButtons(false)
                    web.postDelayed({ inspectRouterPage() }, 700)
                }

                else -> {
                    if (inspectAttempts < 8) {
                        inspectAttempts++
                        web.postDelayed({ inspectRouterPage() }, 600)
                    } else {
                        connected = false
                        currentPageLooksLikeMacFilter = false
                        setButtons(false)
                        if (r == "LOGIN_PAGE") {
                            if (loginAttempts < 3) {
                                loginAttempts++
                                status.text = "Iniciando sesión en el router…"
                                details.text = "Usando las credenciales del router y manteniendo la misma sesión CGI."
                                autoLogin()
                            } else {
                                status.text = "El router pide iniciar sesión"
                                details.text = "No pude completar automáticamente el inicio de sesión con las credenciales configuradas."
                            }
                        } else {
                            status.text = "Router conectado, pero no encontré MAC Filter"
                            details.text = "La interfaz respondió, pero la página MAC Filter todavía no fue localizada."
                        }
                    }
                }
            }
        }
    }

    private fun autoLogin() {
        val user = jsQuote(ROUTER_USER)
        val pass = jsQuote(ROUTER_PASSWORD)
        val js = """
            (function(){
              var USER=$user, PASS=$pass;
              function walk(w,out,depth){
                if(depth>8)return;
                try{out.push(w.document);}catch(e){}
                try{for(var i=0;i<w.frames.length;i++)walk(w.frames[i],out,depth+1);}catch(e){}
              }
              function clean(s){return ((s||'')+'').replace(/\s+/g,' ').trim().toLowerCase();}
              function label(e){
                var s='';
                try{s+=' '+clean(e.name)+' '+clean(e.id)+' '+clean(e.placeholder)+' '+clean(e.title)+' '+clean(e.getAttribute('aria-label'));}catch(x){}
                try{
                  if(e.labels) for(var i=0;i<e.labels.length;i++) s+=' '+clean(e.labels[i].innerText||e.labels[i].textContent);
                }catch(x){}
                return s;
              }
              function setv(e,v){
                try{
                  var p=e.ownerDocument.defaultView.HTMLInputElement.prototype;
                  var d=Object.getOwnPropertyDescriptor(p,'value');
                  if(d&&d.set)d.set.call(e,v);else e.value=v;
                }catch(x){try{e.value=v;}catch(y){}}
                try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(x){}
                try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(x){}
              }
              function click(e){
                try{e.click();return true;}catch(x){}
                try{
                  var ev=e.ownerDocument.createEvent('MouseEvents');
                  ev.initMouseEvent('click',true,true,e.ownerDocument.defaultView,1,0,0,0,0,false,false,false,false,0,null);
                  e.dispatchEvent(ev);return true;
                }catch(x){}
                return false;
              }
              var ds=[];walk(window,ds,0);
              for(var d=0;d<ds.length;d++){
                try{
                  var doc=ds[d], inputs=doc.querySelectorAll('input,textarea');
                  var pw=null, un=null;
                  for(var i=0;i<inputs.length;i++){
                    var e=inputs[i], typ=(e.type||'').toLowerCase(), l=label(e);
                    if(!pw && (typ==='password' || l.indexOf('password')>=0 || l.indexOf('passwd')>=0 || l.indexOf('pwd')>=0 || l.indexOf('psw')>=0 || l.indexOf('pass')>=0)) pw=e;
                  }
                  if(!pw) continue;
                  for(var j=0;j<inputs.length;j++){
                    var q=inputs[j], qt=(q.type||'').toLowerCase(), ql=label(q);
                    if(q===pw || qt==='password' || qt==='hidden') continue;
                    if(qt==='text' || qt==='email' || qt==='tel' || qt===''){
                      if(ql.indexOf('user')>=0 || ql.indexOf('userid')>=0 || ql.indexOf('username')>=0 || ql.indexOf('login')>=0 || ql.indexOf('account')>=0 || ql.indexOf('name')>=0){un=q;break;}
                    }
                  }
                  if(!un){
                    for(var k=0;k<inputs.length;k++){
                      var z=inputs[k], zt=(z.type||'').toLowerCase();
                      if(zt==='text' || zt==='email'){un=z;break;}
                    }
                  }
                  if(un) setv(un,USER);
                  setv(pw,PASS);
                  var passValue='';
                  try{passValue=(pw.value||'')+'';}catch(x){}
                  if(passValue !== PASS){
                    return 'NO_PASSWORD_FIELD';
                  }

                  var form=pw.form;
                  if(form){
                    var btns=form.querySelectorAll('input[type=submit],input[type=button],button,a');
                    for(var b=0;b<btns.length;b++){
                      var bt=clean(btns[b].value||btns[b].innerText||btns[b].textContent||btns[b].title);
                      if(bt.indexOf('login')>=0 || bt.indexOf('sign in')>=0 || bt.indexOf('entrar')>=0 || bt.indexOf('ingresar')>=0 || bt.indexOf('ok')>=0){
                        click(btns[b]); return 'SUBMITTED';
                      }
                    }
                    try{HTMLFormElement.prototype.submit.call(form);return 'SUBMITTED';}catch(x){}
                  }
                  var all=doc.querySelectorAll('input[type=submit],input[type=button],button');
                  for(var c=0;c<all.length;c++){
                    var ct=clean(all[c].value||all[c].innerText||all[c].textContent||all[c].title);
                    if(ct.indexOf('login')>=0 || ct.indexOf('entrar')>=0 || ct.indexOf('ingresar')>=0 || ct==='ok'){click(all[c]);return 'SUBMITTED';}
                  }
                }catch(e){}
              }
              return 'NO_FORM';
            })();
        """.trimIndent()
        web.evaluateJavascript(js) { raw ->
            val r = decodeJsResult(raw)
            when (r) {
                "SUBMITTED" -> web.postDelayed({ inspectRouterPage() }, 1200)
                "NO_PASSWORD_FIELD" -> {
                    status.text = "No pude completar el campo de contraseña"
                    details.text = "El router usa un formulario CGI distinto; no se envió una contraseña vacía."
                    web.postDelayed({ inspectRouterPage() }, 700)
                }
                else -> web.postDelayed({ inspectRouterPage() }, 500)
            }
        }
    }

    private fun setButtons(enabled: Boolean) {
        val ok = enabled && !operationRunning
        block.isEnabled = ok
        unblock.isEnabled = ok
    }

    private fun performMacOperation(operation: String) {
        val target = mac.text.toString().trim().uppercase(Locale.US)
        if (!Regex("^[0-9A-F]{2}(:[0-9A-F]{2}){5}$").matches(target)) {
            mac.error = "Usa AA:BB:CC:DD:EE:FF"
            return
        }
        if (!connected || !currentPageLooksLikeMacFilter) {
            status.text = "Primero conecta con el router"
            return
        }
        if (operationRunning) return

        pendingOperation = operation
        pendingMac = target
        operationRunning = true
        operationVerifyAttempts = 0
        setButtons(false)
        status.text = if (operation == "add") "Bloqueando $target…" else "Desbloqueando $target…"
        details.text = "Usando la página MAC Filter del router para aplicar el cambio."

        val escaped = jsQuote(target)
        val add = operation == "add"

        val js = """
            (function(){
              window.__rm_result='RUNNING';
              var MAC=$escaped;
              var ADD=${add};

              function walk(w,out,depth){
                if(depth>8)return;
                try{out.push(w);}catch(e){}
                try{for(var i=0;i<w.frames.length;i++)walk(w.frames[i],out,depth+1);}catch(e){}
              }
              var wins=[]; walk(window,wins,0);

              function clean(s){return ((s||'')+'').replace(/\s+/g,' ').trim();}
              function finish(v){window.__rm_result=v;}

              function findInput(w){
                var doc=w.document;
                var names=['macfilter_scmac','src_macaddress','source_mac','sourcemac','source_mac_address','srcmac'];
                for(var i=0;i<names.length;i++){
                  var e=doc.querySelector('input[name="'+names[i]+'"],input[id="'+names[i]+'"]');
                  if(e && !e.disabled)return e;
                }
                return null;
              }

              function setValue(e,v){
                try{
                  var setter=Object.getOwnPropertyDescriptor(
                    e.ownerDocument.defaultView.HTMLInputElement.prototype,'value'
                  );
                  if(setter && setter.set)setter.set.call(e,v);else e.value=v;
                }catch(x){try{e.value=v;}catch(y){}}
                try{e.dispatchEvent(new Event('input',{bubbles:true}));}catch(x){}
                try{e.dispatchEvent(new Event('change',{bubbles:true}));}catch(x){}
                return ((e.value||'').toUpperCase().replace(/\s/g,''))===v.toUpperCase().replace(/\s/g,'');
              }

              function findRow(w){
                var rows=w.document.querySelectorAll('tr');
                for(var i=0;i<rows.length;i++){
                  var tx=((rows[i].innerText||rows[i].textContent||'')+'').toUpperCase();
                  if(tx.indexOf(MAC.toUpperCase())>=0)return rows[i];
                }
                return null;
              }

              function nativeAdd(w){
                // Put the router page into its real "add entry" state first.
                // AddNewEntry() sets operation=add and prepares the same form
                // used by the browser UI.
                try{
                  if(typeof w.AddNewEntry==='function') w.AddNewEntry();
                }catch(e){}

                var input=findInput(w);
                if(!input){finish('NO_MAC_INPUT');return;}
                if(!setValue(input,MAC)){finish('NO_MAC_INPUT');return;}

                // Use the router's own AddEntry() function. This is important:
                // it fills the hidden fields exactly as the real web interface
                // does, including its current sessionkey/cookie.
                try{
                  if(typeof w.AddEntry==='function'){
                    w.AddEntry();
                    return;
                  }
                }catch(e){}
                finish('NO_ROUTER_ADD_FUNCTION');
              }

              function nativeDelete(w){
                var row=findRow(w);
                if(!row){finish('NOT_FOUND');return;}

                // Clear every selection first so we cannot accidentally remove
                // another entry, then select only the requested MAC.
                try{
                  var all=w.document.querySelectorAll('input[name="macfilter_selectindex"]');
                  for(var i=0;i<all.length;i++)all[i].checked=false;
                }catch(e){}

                var cb=row.querySelector('input[name="macfilter_selectindex"]');
                if(!cb)cb=row.querySelector('input[type="checkbox"]');
                if(!cb){finish('NO_DELETE_CHECKBOX');return;}
                cb.checked=true;
                try{cb.dispatchEvent(new Event('change',{bubbles:true}));}catch(e){}

                // Use the router's own DelEntry() function so delnumberlist,
                // operation and the current sessionkey are generated exactly
                // like the real browser request captured in PCAPdroid.
                try{
                  if(typeof w.DelEntry==='function'){
                    w.DelEntry();
                    return;
                  }
                }catch(e){}
                finish('NO_ROUTER_DELETE_FUNCTION');
              }

              // The MAC Filter page is normally the top document. We still
              // search every same-origin frame to keep compatibility with old
              // firmware layouts.
              for(var i=0;i<wins.length;i++){
                try{
                  if(ADD){
                    if(findInput(wins[i])){
                      nativeAdd(wins[i]);
                      return 'RUNNING';
                    }
                  }else{
                    if(findRow(wins[i])){
                      nativeDelete(wins[i]);
                      return 'RUNNING';
                    }
                  }
                }catch(e){}
              }

              finish(ADD?'NO_MAC_INPUT':'NOT_FOUND');
              return 'RUNNING';
            })();
        """.trimIndent()

        web.evaluateJavascript(js) {
            web.postDelayed({ pollOperationResult() }, 500)
        }
    }

    private fun verifyOperationAfterNavigation() {
        operationVerifyAttempts++
        val wanted = pendingMac ?: run {
            operationRunning = false
            setButtons(connected)
            return
        }
        val add = pendingOperation == "add"
        val escaped = jsQuote(wanted)

        val js = """
            (function(){
              var MAC=$escaped;
              function walk(w,out,depth){
                if(depth>8)return;
                try{out.push(w.document);}catch(e){}
                try{for(var i=0;i<w.frames.length;i++)walk(w.frames[i],out,depth+1);}catch(e){}
              }
              var ds=[];walk(window,ds,0);
              var found=false, page=false;
              for(var d=0;d<ds.length;d++){
                try{
                  var tx=((ds[d].body&&ds[d].body.innerText)||'').toUpperCase();
                  if(tx.indexOf('MAC FILTER')>=0 || tx.indexOf('SOURCE MAC ADDRESS')>=0) page=true;
                  if(tx.indexOf(MAC.toUpperCase())>=0) found=true;
                }catch(e){}
              }
              return (page?'PAGE':'NOPAGE')+':'+(found?'FOUND':'ABSENT');
            })();
        """.trimIndent()

        web.evaluateJavascript(js) { raw ->
            val r = decodeJsResult(raw)
            val success = if (add) r.endsWith(":FOUND") else r.endsWith(":ABSENT")
            if (success) {
                operationRunning = false
                connected = r.startsWith("PAGE")
                currentPageLooksLikeMacFilter = connected
                setButtons(connected)
                if (add) {
                    status.text = "MAC bloqueada ✓"
                    details.text = "El router confirmó la entrada en MAC Filter."
                } else {
                    status.text = "MAC desbloqueada ✓"
                    details.text = "El router ya no muestra esa MAC en la lista."
                }
            } else {
                web.postDelayed({
                    web.evaluateJavascript("document.body && document.body.innerText || ''") { again ->
                        val text = decodeJsResult(again).uppercase(Locale.US)
                        val found = text.contains(wanted.uppercase(Locale.US))
                        val page = text.contains("MAC FILTER") || text.contains("SOURCE MAC ADDRESS")
                        val done = if (add) found else page && !found
                        if (done) {
                            operationRunning = false
                            connected = page
                            currentPageLooksLikeMacFilter = page
                            setButtons(page)
                            status.text = if (add) "MAC bloqueada ✓" else "MAC desbloqueada ✓"
                            details.text = "Cambio confirmado en la página del router."
                        } else if (operationVerifyAttempts < 10) {
                            // Give the old CGI a little more time to finish.
                            web.postDelayed({ verifyOperationAfterNavigation() }, 700)
                        } else {
                            operationRunning = false
                            setButtons(connected)
                            status.text = "El router no confirmó el cambio"
                            details.text = "La página respondió, pero no pude verificar que la MAC cambiara."
                        }
                    }
                }, 700)
            }
        }
    }

    private fun pollOperationResult() {
        web.evaluateJavascript("window.__rm_result || 'RUNNING'") { raw ->
            val r = decodeJsResult(raw)
            if (r == "RUNNING" || r.isBlank()) {
                web.postDelayed({ pollOperationResult() }, 500)
                return@evaluateJavascript
            }

            operationRunning = false
            setButtons(connected)

            when (r) {
                "ADD_SENT" -> {
                    status.text = "MAC bloqueada ✓"
                    details.text = "La orden se envió desde la página MAC Filter del router."
                }
                "DELETE_SENT" -> {
                    status.text = "MAC desbloqueada ✓"
                    details.text = "La entrada se eliminó y se aplicó el cambio en el router."
                }
                "NOT_FOUND" -> {
                    status.text = "Esa MAC no está en la lista"
                    details.text = "No encontré $pendingMac entre las entradas actuales."
                }
                "NO_MAC_INPUT" -> {
                    status.text = "No encontré el campo Source MAC"
                    details.text = "El firmware usa otra estructura para el campo de MAC."
                }
                "NO_DELETE" -> {
                    status.text = "No encontré cómo eliminar esa MAC"
                    details.text = "La entrada existe, pero este firmware no mostró un control Delete utilizable."
                }
                "NO_APPLY" -> {
                    status.text = "No encontré el botón Apply"
                    details.text = "La orden se preparó, pero no apareció el botón para guardar el cambio."
                }
                else -> {
                    status.text = "No se pudo completar la operación"
                    details.text = r
                }
            }
        }
    }

    private fun decodeJsResult(raw: String): String {
        if (raw == "null") return ""
        return raw
            .removePrefix("\"")
            .removeSuffix("\"")
            .replace("\\n", "\n")
            .replace("\\\"", "\"")
            .replace("\\/", "/")
            .replace("\\\\", "\\")
    }

    private fun jsQuote(value: String): String {
        return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"
    }

    override fun onDestroy() {
        try { web.stopLoading(); web.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }
}
