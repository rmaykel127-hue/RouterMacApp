package com.maykel.routermac

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var ip: EditText
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var block: Button
    private lateinit var unblock: Button
    private lateinit var mac: EditText
    private lateinit var web: WebView

    private var connected = false
    private var currentBase = "http://192.168.1.1"
    private var pendingOperation: String? = null
    private var pendingMac: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ip = findViewById(R.id.routerIp)
        status = findViewById(R.id.status)
        details = findViewById(R.id.details)
        block = findViewById(R.id.block)
        unblock = findViewById(R.id.unblock)
        mac = findViewById(R.id.mac)
        web = findViewById(R.id.routerWeb)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                inspectRouterPage()
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)

        findViewById<Button>(R.id.connect).setOnClickListener { connect() }
        block.setOnClickListener { performMacOperation("add") }
        unblock.setOnClickListener { performMacOperation("delete") }
        setButtons(false)
    }

    private fun baseUrl(): String {
        var host = ip.text.toString().trim()
        if (host.isBlank()) host = "192.168.1.1"
        host = host.removePrefix("http://").removePrefix("https://")
        host = host.substringBefore('/').trim().trimEnd('/')
        return "http://$host"
    }

    private fun connect() {
        currentBase = baseUrl()
        connected = false
        setButtons(false)
        status.text = "Conectando al router…"
        details.text = "Abriendo la misma interfaz web que funciona en el navegador."

        // The router's real web interface is the source of truth for its session,
        // form fields and CGI commands. This avoids guessing undocumented CGI names.
        web.loadUrl("$currentBase/cgi-bin/login.cgi")
    }

    private fun inspectRouterPage() {
        // Some firmware versions open /cgi-bin/login.cgi first and keep
        // "MAC Filter" in a menu/frame. Follow that menu instead of treating
        // the login/menu page as an error.
        val js = """
            (function(){
              function allDocs(win, out){
                try { out.push(win.document); } catch(e) {}
                try { for(var i=0;i<win.frames.length;i++) allDocs(win.frames[i],out); } catch(e) {}
              }
              var docs=[]; allDocs(window,docs);
              var text='';
              var macLink=null;
              for(var i=0;i<docs.length;i++){
                try{
                  text += '\n'+(docs[i].body ? docs[i].body.innerText : '');
                  var els=docs[i].querySelectorAll('a,button,input[type=button],input[type=submit]');
                  for(var j=0;j<els.length;j++){
                    var e=els[j];
                    var t=((e.innerText||e.value||e.title||e.alt||'')+'').trim();
                    var h=((e.getAttribute('href')||'')+'').trim();
                    if(/mac\s*filter/i.test(t) || /mac[_-]?filter/i.test(h)){
                      macLink=e; break;
                    }
                  }
                  if(macLink) break;
                }catch(e){}
              }
              if(macLink){
                try { macLink.scrollIntoView(); } catch(e){}
                try { macLink.click(); return 'FOLLOWED'; } catch(e){}
                try {
                  var h=macLink.getAttribute('href');
                  if(h) return 'HREF:'+h;
                }catch(e){}
              }
              return 'TEXT:'+text.substring(0,2200);
            })();
        """.trimIndent()

        web.evaluateJavascript(js) { result ->
            val decoded = result
                .removePrefix("\"").removeSuffix("\"")
                .replace("\\n", "\n")
                .replace("\\\"", "\"")
                .replace("\\/", "/")
                .replace("\\\\", "\\")

            when {
                decoded == "FOLLOWED" -> {
                    connected = false
                    status.text = "Abriendo MAC Filter…"
                    details.text = "Encontré MAC Filter en la interfaz del router."
                    setButtons(false)
                    web.postDelayed({ inspectRouterPage() }, 700)
                    return@evaluateJavascript
                }
                decoded.startsWith("HREF:") -> {
                    connected = false
                    status.text = "Abriendo MAC Filter…"
                    details.text = "Navegando a la página MAC Filter del router."
                    setButtons(false)
                    val href = decoded.removePrefix("HREF:")
                    web.post {
                        try {
                            val target = when {
                                href.startsWith("http://") || href.startsWith("https://") -> href
                                href.startsWith("/") -> "$currentBase$href"
                                else -> "$currentBase/$href"
                            }
                            web.loadUrl(target)
                        } catch (_: Exception) {
                            status.text = "No pude abrir MAC Filter"
                        }
                    }
                    return@evaluateJavascript
                }
                else -> {
                    val pageText = decoded.removePrefix("TEXT:")
                    if (pageText.contains("login", true) || pageText.contains("password", true) ||
                        pageText.contains("username", true) || pageText.contains("usuario", true)) {
                        connected = false
                        status.text = "El router pide iniciar sesión"
                        details.text = "La conexión funciona, pero la interfaz web necesita la sesión del router."
                        setButtons(false)
                    } else {
                        // IMPORTANT: being connected to the router must not depend
                        // on finding the MAC Filter menu. Some firmware hides that
                        // menu in a frame or exposes it only after navigation.
                        // The old working APK enabled the actions as soon as the
                        // router session was available, so keep that behavior.
                        connected = true
                        status.text = "Router conectado ✓"
                        details.text = "Router conectado. Los botones están listos; al pulsarlos la app buscará MAC Filter."
                        setButtons(true)
                    }
                }
            }
        }
    }

    private fun setButtons(enabled: Boolean) {
        block.isEnabled = enabled
        unblock.isEnabled = enabled
    }

    private fun performMacOperation(operation: String) {
        val target = mac.text.toString().trim().uppercase(Locale.US)
        if (!Regex("^[0-9A-F]{2}(:[0-9A-F]{2}){5}$").matches(target)) {
            mac.error = "Usa AA:BB:CC:DD:EE:FF"
            return
        }
        if (!connected) {
            status.text = "Primero conecta con el router"
            return
        }

        pendingOperation = operation
        pendingMac = target
        setButtons(false)
        status.text = if (operation == "add") "Buscando MAC Filter…" else "Buscando MAC Filter…"
        details.text = "Abriendo la página MAC Filter del router antes de ejecutar la orden."
        openMacFilterThenRun(operation, target)
    }

    private fun openMacFilterThenRun(operation: String, target: String) {
        val js = """
            (function(){
              function allDocs(win,out){
                try{out.push(win.document);}catch(e){}
                try{for(var i=0;i<win.frames.length;i++)allDocs(win.frames[i],out);}catch(e){}
              }
              var ds=[]; allDocs(window,ds);
              for(var d=0;d<ds.length;d++){
                var body=(ds[d].body ? ds[d].body.innerText : '') || '';
                if(/MAC Filter|Source MAC Address|MAC Filter Enable/i.test(body)) return 'READY';
              }
              for(var d=0;d<ds.length;d++){
                var es=ds[d].querySelectorAll('a,button,input[type=button],input[type=submit],[onclick]');
                for(var i=0;i<es.length;i++){
                  var e=es[i];
                  var t=((e.innerText||e.value||e.title||e.alt||'')+'');
                  var h=((e.getAttribute('href')||'')+'');
                  if(/MAC\s*Filter/i.test(t)||/MAC[_-]?Filter/i.test(h)){
                    try{e.click();return 'CLICKED';}catch(x){}
                    if(h)return 'HREF:'+h;
                  }
                }
              }
              return 'NOT_FOUND';
            })();
        """.trimIndent()
        web.evaluateJavascript(js) { result ->
            val r = result.trim('"').replace("\\/", "/").replace("\\\"", "\"")
            when {
                r == "READY" -> runMacOperationScript(operation, target)
                r == "CLICKED" -> web.postDelayed({ waitForMacFilterAndRun(operation, target, 0) }, 500)
                r.startsWith("HREF:") -> {
                    val href = r.removePrefix("HREF:")
                    val targetUrl = when {
                        href.startsWith("http://") || href.startsWith("https://") -> href
                        href.startsWith("/") -> "$currentBase$href"
                        else -> "$currentBase/$href"
                    }
                    web.loadUrl(targetUrl)
                    web.postDelayed({ waitForMacFilterAndRun(operation, target, 0) }, 700)
                }
                else -> {
                    // Try the same page for a short time; some routers populate
                    // the security frame asynchronously.
                    waitForMacFilterAndRun(operation, target, 0)
                }
            }
        }
    }

    private fun waitForMacFilterAndRun(operation: String, target: String, attempt: Int) {
        if (attempt >= 8) {
            runMacOperationScript(operation, target)
            return
        }
        web.evaluateJavascript("(document.body && document.body.innerText || '').toString()") { result ->
            val t = result.replace("\\n", " ").replace("\\\"", "\"")
            if (t.contains("MAC Filter", true) || t.contains("Source MAC Address", true) || t.contains("MAC Filter Enable", true)) {
                runMacOperationScript(operation, target)
            } else {
                web.postDelayed({ waitForMacFilterAndRun(operation, target, attempt + 1) }, 500)
            }
        }
    }

    private fun runMacOperationScript(operation: String, target: String) {
        setButtons(false)
        status.text = if (operation == "add") "Bloqueando $target…" else "Desbloqueando $target…"
        details.text = "Trabajando dentro de la página MAC Filter del router."

        val escaped = jsQuote(target)
        val add = operation == "add"
        val js = """
            (function(){
              var MAC=$escaped;
              function docs(){
                var a=[]; function walk(w){
                  try{a.push(w.document);}catch(e){}
                  try{for(var i=0;i<w.frames.length;i++)walk(w.frames[i]);}catch(e){}
                } walk(window); return a;
              }
              function txt(el){return ((el.innerText||el.value||el.textContent||'')+'').trim().toLowerCase();}
              function fire(el){try{el.scrollIntoView();}catch(e){}; try{el.click();}catch(e){
                try{el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));}catch(x){}
              }}
              function findByValue(words){
                var ds=docs();
                for(var d=0;d<ds.length;d++){
                  var es=ds[d].querySelectorAll('input,button,a,[onclick]');
                  for(var i=0;i<es.length;i++){
                    var t=txt(es[i])+' '+((es[i].getAttribute('title')||'')+'').toLowerCase();
                    for(var j=0;j<words.length;j++) if(t===words[j] || t.indexOf(words[j])>=0) return es[i];
                  }
                } return null;
              }
              function findInput(){
                var names=['src_macaddress','macfilter_scmac','source_mac','sourcemac','source_mac_address','mac','macaddress','mac_addr','mac_address'];
                var ds=docs();
                for(var d=0;d<ds.length;d++){
                  for(var n=0;n<names.length;n++){
                    var e=ds[d].querySelector('input[name="'+names[n]+'"],input[id="'+names[n]+'"]');
                    if(e) return e;
                  }
                  var es=ds[d].querySelectorAll('input[type=text],input:not([type])');
                  for(var i=0;i<es.length;i++){
                    var x=(es[i].name+' '+es[i].id+' '+es[i].placeholder).toLowerCase();
                    if(x.indexOf('mac')>=0 || x.indexOf('source')>=0) return es[i];
                  }
                } return null;
              }
              function findRow(mac){
                var ds=docs();
                for(var d=0;d<ds.length;d++){
                  var rows=ds[d].querySelectorAll('tr');
                  for(var i=0;i<rows.length;i++) if((rows[i].innerText||'').toUpperCase().indexOf(mac)>=0) return rows[i];
                } return null;
              }
              function apply(){
                var a=findByValue(['apply']); if(a){fire(a);return true;} return false;
              }
              function run(){
                var ds=docs();
                if(${add}){
                  var n=findByValue(['new']); if(n) fire(n);
                  setTimeout(function(){
                    var input=findInput();
                    if(!input){ window.__rm_result='NO_MAC_INPUT'; return; }
                    input.value=MAC;
                    input.dispatchEvent(new Event('input',{bubbles:true}));
                    input.dispatchEvent(new Event('change',{bubbles:true}));
                    setTimeout(function(){
                      if(apply()) window.__rm_result='ADD_SENT'; else window.__rm_result='NO_APPLY';
                    },250);
                  },350);
                }else{
                  var row=findRow(MAC);
                  if(!row){ window.__rm_result='NOT_FOUND'; return; }
                  var sel=row.querySelector('input[type=checkbox],input[type=radio],input[type=button]');
                  if(sel && (sel.type==='checkbox'||sel.type==='radio')){sel.checked=true;sel.dispatchEvent(new Event('change',{bubbles:true}));}
                  var del=findByValue(['delete']);
                  if(del) fire(del);
                  setTimeout(function(){ if(apply()) window.__rm_result='DELETE_SENT'; else window.__rm_result='NO_APPLY'; },300);
                }
              }
              window.__rm_result='RUNNING'; run();
              setTimeout(function(){},100);
              return 'RUNNING';
            })();
        """.trimIndent()
        web.evaluateJavascript(js) { pollResult() }
    }

    private fun pollResult() {
        web.evaluateJavascript("window.__rm_result || 'RUNNING'") { result ->
            val r = result.trim('"')
            if (r == "RUNNING" || r == "") {
                web.postDelayed({ pollResult() }, 500)
                return@evaluateJavascript
            }
            runOnUiThread {
                setButtons(connected)
                when (r) {
                    "ADD_SENT" -> {
                        status.text = "MAC enviada al router ✓"
                        details.text = "El router recibió la orden desde su propia página MAC Filter."
                    }
                    "DELETE_SENT" -> {
                        status.text = "MAC desbloqueada ✓"
                        details.text = "La entrada seleccionada fue eliminada y se pulsó Apply."
                    }
                    "NOT_FOUND" -> {
                        status.text = "Esa MAC no está en la lista"
                        details.text = "No se encontró $pendingMac en las entradas actuales."
                    }
                    "NO_MAC_INPUT" -> {
                        status.text = "No encontré el campo Source MAC"
                        details.text = "El router usa un campo distinto en esta versión del firmware."
                    }
                    "NO_APPLY" -> {
                        status.text = "No encontré el botón Apply"
                        details.text = "La página del router no mostró el botón Apply a la app."
                    }
                    else -> {
                        status.text = "La operación terminó con respuesta desconocida"
                        details.text = r
                    }
                }
            }
        }
    }

    private fun jsQuote(value: String): String {
        return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"
    }
}
