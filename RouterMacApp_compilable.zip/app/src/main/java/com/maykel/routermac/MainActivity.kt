package com.maykel.routermac

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.net.URLDecoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {
    private lateinit var ip: EditText
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var block: Button
    private lateinit var unblock: Button
    private lateinit var mac: EditText

    private val cookieJar = SimpleCookieJar()
    private val client = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(false)
        .build()

    private var sessionKey: String? = null
    private var host: String = "192.168.1.1"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ip = findViewById(R.id.routerIp)
        status = findViewById(R.id.status)
        details = findViewById(R.id.details)
        block = findViewById(R.id.block)
        unblock = findViewById(R.id.unblock)
        mac = findViewById(R.id.mac)

        findViewById<Button>(R.id.connect).setOnClickListener { connect() }
        block.setOnClickListener { sendMacFilter("add") }
        unblock.setOnClickListener { sendMacFilter("delete") }
        setButtons(false)
    }

    private fun cleanHost(): String {
        var h = ip.text.toString().trim()
        h = h.removePrefix("http://").removePrefix("https://")
        h = h.substringBefore('/').trim().trimEnd('/')
        return if (h.isBlank()) "192.168.1.1" else h
    }

    private fun connect() {
        host = cleanHost()
        sessionKey = null
        setButtons(false)
        status.text = "Conectando al router…"
        details.text = "Leyendo la sesión CGI del router."

        Thread {
            try {
                // The working firmware exposes its session through the CGI
                // interface. Keep the HTTP session/cookies instead of using a
                // WebView, because the router's MAC Filter form is a legacy CGI.
                val htmls = mutableListOf<String>()
                val paths = listOf("/cgi-bin/login.cgi", "/", "/cgi-bin/main.cgi")
                for (path in paths) {
                    try {
                        val response = get(path)
                        val body = response.body?.string().orEmpty()
                        if (body.isNotBlank()) htmls.add(body)
                        val key = extractSession(body)
                        if (!key.isNullOrBlank()) {
                            sessionKey = key
                            break
                        }
                    } catch (_: Exception) { }
                }

                // Some versions place the key in the MAC Filter page itself.
                if (sessionKey.isNullOrBlank()) {
                    try {
                        val body = get("/cgi-bin/macfilter.cgi").body?.string().orEmpty()
                        htmls.add(body)
                        sessionKey = extractSession(body)
                    } catch (_: Exception) { }
                }

                val all = htmls.joinToString("\n")
                val localMac = extract(all, """localmac\\s*=\\s*[\"']([^\"']+)[\"']""")
                    ?: extract(all, """local_mac\\s*=\\s*[\"']([^\"']+)[\"']""")
                val mode = extract(all, """filtermode\\s*=\\s*[\"']([^\"']+)[\"']""")

                runOnUiThread {
                    if (!sessionKey.isNullOrBlank()) {
                        status.text = "Router conectado ✓"
                        details.text = "HTTP 200\nSesión CGI: encontrada\nMAC local: ${localMac ?: "no encontrada"}\nMAC Filter: listo"
                        setButtons(true)
                    } else {
                        status.text = "Router conectado, pero no pude obtener la sesión"
                        details.text = "El router responde, pero no entregó sessionkey."
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Error: ${e.message ?: "sin respuesta"}"
                    details.text = "Comprueba que el teléfono esté conectado al Wi‑Fi del router."
                    setButtons(false)
                }
            }
        }.start()
    }

    private fun get(path: String): Response {
        val url = "http://$host${if (path.startsWith('/')) path else "/$path"}"
        return client.newCall(
            Request.Builder()
                .url(url)
                .get()
                .header("Cache-Control", "no-cache")
                .build()
        ).execute()
    }

    private fun sendMacFilter(operation: String) {
        val targetMac = mac.text.toString().trim().lowercase()
        if (!Regex("^[0-9a-f]{2}(:[0-9a-f]{2}){5}$").matches(targetMac)) {
            mac.error = "Usa AA:BB:CC:DD:EE:FF"
            return
        }
        if (sessionKey.isNullOrBlank()) {
            status.text = "Primero conecta con el router"
            return
        }

        setButtons(false)
        status.text = if (operation == "add") "Bloqueando $targetMac…" else "Desbloqueando $targetMac…"
        details.text = "Enviando la orden directamente al CGI MAC Filter."

        Thread {
            try {
                // Read the actual MAC Filter form first. This preserves any
                // hidden firmware-specific values that this router requires.
                val pageResponse = get("/cgi-bin/macfilter.cgi")
                val page = pageResponse.body?.string().orEmpty()
                val freshKey = extractSession(page)
                if (!freshKey.isNullOrBlank()) sessionKey = freshKey

                val hidden = extractHiddenInputs(page).toMutableMap()
                hidden["sessionkey"] = sessionKey.orEmpty()
                hidden["onSubmit"] = "1"
                hidden["operation"] = operation
                hidden["src_macaddress"] = targetMac
                hidden["dst_macaddress"] = ""
                hidden["macfilter_enable"] = hidden["macfilter_enable"] ?: "on"
                hidden["macfilter_mode"] = hidden["macfilter_mode"] ?: "Exclude"
                hidden["filter_selectindex"] = hidden["filter_selectindex"] ?: "1"
                hidden["macfilter_protocol"] = hidden["macfilter_protocol"] ?: "IP"
                hidden["macfilter_scmac"] = hidden["macfilter_scmac"] ?: ""
                hidden["macfilter_dsmac"] = hidden["macfilter_dsmac"] ?: ""
                hidden["filter_enable"] = hidden["filter_enable"] ?: ""
                hidden["modify_index"] = hidden["modify_index"] ?: findModifyIndex(page, targetMac).orEmpty()
                hidden["delnumberlist"] = if (operation == "delete") "1" else ""

                val form = FormBody.Builder().apply {
                    hidden.forEach { (k, v) ->
                        if (k.isNotBlank()) add(k, v)
                    }
                }.build()

                val request = Request.Builder()
                    .url("http://$host/cgi-bin/macfilter.cgi")
                    .post(form)
                    .header("Origin", "http://$host")
                    .header("Referer", "http://$host/cgi-bin/macfilter.cgi")
                    .header("Cache-Control", "no-cache")
                    .build()

                client.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    val ok = response.isSuccessful
                    runOnUiThread {
                        setButtons(true)
                        if (ok) {
                            status.text = if (operation == "add") "MAC bloqueada ✓" else "MAC desbloqueada ✓"
                            details.text = "HTTP ${response.code}\nMAC: $targetMac\nVerificación: ${verifyResult(body, targetMac, operation)}"
                        } else {
                            status.text = "El router respondió HTTP ${response.code}"
                            details.text = body.take(700)
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setButtons(true)
                    status.text = "Error enviando la petición"
                    details.text = e.message ?: "No se pudo enviar la orden."
                }
            }
        }.start()
    }

    private fun extractSession(text: String): String? {
        val patterns = listOf(
            """(?:gcsessionkey|sessionkey|session_key)\\s*=\\s*[\"']([^\"']+)[\"']""",
            """name\\s*=\\s*[\"'](?:gcsessionkey|sessionkey|session_key)[\"'][^>]*value\\s*=\\s*[\"']([^\"']+)[\"']""",
            """value\\s*=\\s*[\"']([^\"']+)[\"'][^>]*name\\s*=\\s*[\"'](?:gcsessionkey|sessionkey|session_key)[\"']"""
        )
        for (p in patterns) extract(text, p)?.let { return it }
        return null
    }

    private fun extractHiddenInputs(html: String): Map<String, String> {
        val out = linkedMapOf<String, String>()
        val re = Pattern.compile(
            "<input[^>]+type\\s*=\\s*[\\\"']hidden[\\\"'][^>]*>",
            Pattern.CASE_INSENSITIVE
        )
        val m = re.matcher(html)
        while (m.find()) {
            val tag = m.group()
            val name = extract(tag, """name\\s*=\\s*[\"']([^\"']+)[\"']""") ?: continue
            val value = extract(tag, """value\\s*=\\s*[\"']([^\"']*)[\"']""") ?: ""
            out[name] = htmlDecode(value)
        }
        return out
    }

    private fun findModifyIndex(html: String, mac: String): String? {
        val normalized = mac.replace(":", "[-:]?").replace("-", "")
        val rowPattern = Pattern.compile("(?is)<tr[^>]*>.*?$normalized.*?</tr>")
        val row = rowPattern.matcher(html)
        if (row.find()) {
            val chunk = row.group()
            extract(chunk, """(?:name|id)\\s*=\\s*[\"'](?:modify_?index|index)[\"'][^>]*value\\s*=\\s*[\"']([^\"']*)[\"']""")?.let { return it }
            extract(chunk, """value\\s*=\\s*[\"']([^\"']+)[\"'][^>]*(?:modify_?index|index)""")?.let { return it }
        }
        return null
    }

    private fun verifyResult(body: String, mac: String, operation: String): String {
        val lower = body.lowercase()
        return when {
            operation == "add" && (lower.contains(mac.lowercase()) || lower.contains(mac.replace(":", ""))) -> "correcta"
            operation == "delete" && !lower.contains(mac.lowercase()) -> "correcta"
            else -> "enviada"
        }
    }

    private fun htmlDecode(value: String): String = URLDecoder.decode(value.replace("&quot;", "\""), "UTF-8")

    private fun extract(text: String, regex: String): String? {
        val m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(text)
        return if (m.find()) m.group(1) else null
    }

    private fun setButtons(enabled: Boolean) {
        block.isEnabled = enabled
        unblock.isEnabled = enabled
    }
}

class SimpleCookieJar : CookieJar {
    private val cookies = mutableListOf<Cookie>()

    @Synchronized override fun saveFromResponse(url: HttpUrl, newCookies: List<Cookie>) {
        newCookies.forEach { incoming ->
            cookies.removeAll {
                it.name == incoming.name && it.domain == incoming.domain && it.path == incoming.path
            }
            cookies.add(incoming)
        }
    }

    @Synchronized override fun loadForRequest(url: HttpUrl): List<Cookie> =
        cookies.filter { it.matches(url) }
}
