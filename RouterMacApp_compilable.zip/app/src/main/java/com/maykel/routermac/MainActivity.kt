package com.maykel.routermac

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {
    private lateinit var ip: EditText
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var block: Button
    private lateinit var unblock: Button
    private lateinit var mac: EditText

    private val cookieJar = SimpleCookieJar()
    private val client = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    // Some routers expose a session key in HTML, others only use the cookie.
    // A successful connection is therefore enough to unlock the filter buttons.
    private var connected = false
    private var sessionKey: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ip = findViewById(R.id.routerIp)
        status = findViewById(R.id.status)
        details = findViewById(R.id.details)
        block = findViewById(R.id.block)
        unblock = findViewById(R.id.unblock)
        mac = findViewById(R.id.mac)

        findViewById<Button>(R.id.connect).setOnClickListener { connect() }
        block.setOnClickListener { sendMacFilter("add") }
        unblock.setOnClickListener { sendMacFilter("delete") }
    }

    private fun baseUrl(): String {
        var host = ip.text.toString().trim()
        if (host.isBlank()) host = "192.168.1.1"

        // Accept both "192.168.1.1" and a full URL/path pasted by mistake.
        host = host.removePrefix("http://").removePrefix("https://")
        host = host.substringBefore("/").trim().trimEnd('/')

        return "http://$host"
    }

    private fun connect() {
        val base = baseUrl()
        status.text = "Conectando…"
        setButtons(false)

        Thread {
            try {
                // First visit the router login CGI. This is important because
                // several firmwares create the authenticated session here.
                val loginUrl = "$base/cgi-bin/login.cgi"
                val request = Request.Builder()
                    .url(loginUrl)
                    .get()
                    .header("Accept", "text/html,*/*")
                    .build()

                client.newCall(request).execute().use { response ->
                    val html = response.body?.string().orEmpty()

                    sessionKey =
                        extract(html, """(?:gcsessionkey|sessionkey|sessionKey)\s*=\s*["']([^"']+)["']""")
                            ?: extract(html, """name=["']sessionkey["'][^>]*value=["']([^"']+)["']""")
                            ?: cookieJar.findValue("sessionkey")
                            ?: cookieJar.findValue("gcsessionkey")

                    if (!response.isSuccessful) {
                        runOnUiThread {
                            status.text = "El router respondió HTTP ${response.code}"
                            details.text = html.take(700)
                            setButtons(false)
                        }
                        return@use
                    }

                    // Load the actual MAC filter page with the same cookie/session.
                    val filterRequest = Request.Builder()
                        .url("$base/cgi-bin/macfilter.cgi")
                        .get()
                        .header("Accept", "text/html,*/*")
                        .header("Referer", loginUrl)
                        .build()

                    client.newCall(filterRequest).execute().use { filterResponse ->
                        val filterHtml = filterResponse.body?.string().orEmpty()

                        val filterSession =
                            extract(filterHtml, """(?:gcsessionkey|sessionkey|sessionKey)\s*=\s*["']([^"']+)["']""")
                                ?: extract(filterHtml, """name=["']sessionkey["'][^>]*value=["']([^"']+)["']""")
                                ?: sessionKey
                                ?: cookieJar.findValue("sessionkey")
                                ?: cookieJar.findValue("gcsessionkey")

                        sessionKey = filterSession
                        connected = response.isSuccessful && filterResponse.isSuccessful

                        val localMac = extract(
                            filterHtml,
                            """(?i)(?:localmac|local_mac|macaddr|mac_address)\s*[:=]\s*["']?([0-9a-f]{2}(?::[0-9a-f]{2}){5})"""
                        )
                        val mode = extract(
                            filterHtml,
                            """(?i)(?:filtermode|macfilter_mode)\s*[:=]\s*["']?([^"'<\s;]+)"""
                        )
                        val entries = extract(
                            filterHtml,
                            """(?i)(?:Current Entry Number|current\s*entry\s*number)[^0-9]*([0-9]+)"""
                        )

                        runOnUiThread {
                            status.text = if (connected) "Router conectado ✓" else "No se pudo abrir el filtro MAC"
                            details.text =
                                "HTTP ${filterResponse.code}\n" +
                                "Sesión: ${if (sessionKey.isNullOrBlank()) "cookie/sesión del router" else "encontrada"}\n" +
                                "Entradas MAC: ${entries ?: "no indicada"}\n" +
                                "Modo: ${mode ?: "Black List / router"}" +
                                (if (localMac != null) "\nMAC local: $localMac" else "")
                            setButtons(connected)
                        }
                    }
                }
            } catch (e: Exception) {
                connected = false
                runOnUiThread {
                    status.text = "Error: ${e.message ?: "sin respuesta"}"
                    details.text = "Comprueba que el teléfono esté conectado al Wi‑Fi del router."
                    setButtons(false)
                }
            }
        }.start()
    }

    private fun setButtons(enabled: Boolean) {
        block.isEnabled = enabled
        unblock.isEnabled = enabled
    }

    private fun sendMacFilter(operation: String) {
        val base = baseUrl()
        val targetMac = mac.text.toString().trim().uppercase()

        if (!Regex("^[0-9A-F]{2}(:[0-9A-F]{2}){5}$").matches(targetMac)) {
            mac.error = "Usa AA:BB:CC:DD:EE:FF"
            return
        }
        if (!connected) {
            status.text = "Primero conecta con el router"
            return
        }

        status.text = if (operation == "add") "Bloqueando $targetMac…" else "Desbloqueando $targetMac…"
        setButtons(false)

        Thread {
            try {
                // Read the router's real form first. Different firmware revisions
                // use different hidden field names; preserving them is safer than
                // sending a guessed form.
                val pageRequest = Request.Builder()
                    .url("$base/cgi-bin/macfilter.cgi")
                    .get()
                    .header("Accept", "text/html,*/*")
                    .build()

                client.newCall(pageRequest).execute().use { pageResponse ->
                    val html = pageResponse.body?.string().orEmpty()
                    if (!pageResponse.isSuccessful) {
                        showError("No se pudo abrir MAC Filter (HTTP ${pageResponse.code})", html)
                        return@use
                    }

                    val formAction = extract(
                        html,
                        """(?is)<form[^>]+action=["']([^"']*macfilter[^"']*)["']"""
                    )?.let { action ->
                        if (action.startsWith("http://") || action.startsWith("https://")) action
                        else if (action.startsWith("/")) "$base$action" else "$base/$action"
                    } ?: "$base/cgi-bin/macfilter.cgi"

                    val fields = parseFormFields(html).toMutableMap()

                    // Names visible in this router's page are preferred.
                    putIfPresent(fields, "macfilter_enable", "on")
                    putIfPresent(fields, "filter_enable", "on")
                    putIfPresent(fields, "macfilter_mode", "Exclude")
                    putIfPresent(fields, "filtermode", "Black List")
                    putIfPresent(fields, "operation", operation)
                    putIfPresent(fields, "onSubmit", "1")
                    putIfPresent(fields, "src_macaddress", targetMac)
                    putIfPresent(fields, "macfilter_scmac", targetMac)
                    putIfPresent(fields, "source_mac", targetMac)
                    putIfPresent(fields, "SourceMac", targetMac)
                    putIfPresent(fields, "dst_macaddress", "")
                    putIfPresent(fields, "macfilter_dsmac", "")

                    if (!sessionKey.isNullOrBlank()) {
                        putIfPresent(fields, "sessionkey", sessionKey!!)
                        putIfPresent(fields, "gcsessionkey", sessionKey!!)
                    }

                    if (operation == "add") {
                        // The UI shown by the user uses New, so ask the firmware
                        // to create a new entry rather than delete/modify one.
                        putIfPresent(fields, "new", "1")
                        putIfPresent(fields, "action", "new")
                        putIfPresent(fields, "modify_index", "")
                        putIfPresent(fields, "delnumberlist", "")
                    } else {
                        putIfPresent(fields, "delete", "1")
                        putIfPresent(fields, "action", "delete")
                        putIfPresent(fields, "delnumberlist", "1")
                    }

                    // If the page has a selected entry index, use it for delete.
                    if (operation == "delete") {
                        val index = extract(
                            html,
                            """(?is)(?:filter_selectindex|modify_index)["'\s=>]+(?:<[^>]*>)?\s*([0-9]+)"""
                        )
                        if (index != null) {
                            putIfPresent(fields, "filter_selectindex", index)
                            putIfPresent(fields, "modify_index", index)
                        }
                    }

                    val form = FormBody.Builder()
                    fields.forEach { (k, v) -> form.add(k, v) }

                    val post = Request.Builder()
                        .url(formAction)
                        .post(form.build())
                        .header("Origin", base)
                        .header("Referer", "$base/cgi-bin/macfilter.cgi")
                        .header("Accept", "text/html,*/*")
                        .build()

                    client.newCall(post).execute().use { response ->
                        val body = response.body?.string().orEmpty()

                        // Many old routers return 200 even when the operation was
                        // rejected. Reload the page to verify the MAC is actually
                        // present/absent before reporting success.
                        val verifyRequest = Request.Builder()
                            .url("$base/cgi-bin/macfilter.cgi")
                            .get()
                            .header("Accept", "text/html,*/*")
                            .build()

                        client.newCall(verifyRequest).execute().use { verify ->
                            val verifyHtml = verify.body?.string().orEmpty()
                            val normalized = verifyHtml.uppercase()
                            val present = normalized.contains(targetMac)

                            val success = response.isSuccessful &&
                                    ((operation == "add" && present) ||
                                     (operation == "delete" && !present))

                            runOnUiThread {
                                if (success) {
                                    status.text =
                                        if (operation == "add") "MAC bloqueada ✓"
                                        else "MAC desbloqueada ✓"
                                    details.text =
                                        "HTTP ${response.code}\nMAC: $targetMac\n" +
                                        "Verificación: correcta"
                                } else {
                                    status.text =
                                        "El router recibió la petición, pero no confirmó el cambio"
                                    details.text =
                                        "HTTP ${response.code}\nMAC: $targetMac\n" +
                                        "Respuesta: ${body.take(500)}"
                                }
                                setButtons(connected)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Error enviando la petición: ${e.message ?: "sin respuesta"}"
                    setButtons(connected)
                }
            }
        }.start()
    }

    private fun parseFormFields(html: String): Map<String, String> {
        val result = linkedMapOf<String, String>()
        val inputPattern = Pattern.compile(
            """(?is)<input\b[^>]*\bname=["']([^"']+)["'][^>]*>"""
        )
        val matcher = inputPattern.matcher(html)
        while (matcher.find()) {
            val tag = matcher.group(0)
            val name = matcher.group(1)
            val type = extract(tag, """(?i)\btype=["']([^"']+)["']""") ?: "text"
            if (type.equals("submit", true) || type.equals("button", true) ||
                type.equals("reset", true) || type.equals("file", true)) continue

            val checked = Regex("""(?i)\bchecked\b""").containsMatchIn(tag)
            val value = extract(tag, """(?i)\bvalue=["']([^"']*)["']""") ?: ""
            if (type.equals("checkbox", true) && !checked) continue
            result[name] = value
        }
        return result
    }

    private fun putIfPresent(map: MutableMap<String, String>, key: String, value: String) {
        if (map.containsKey(key)) map[key] = value
    }

    private fun cookieValue(name: String): String? = cookieJar.findValue(name)

    private fun showError(message: String, body: String) {
        runOnUiThread {
            status.text = message
            details.text = body.take(700)
            setButtons(connected)
        }
    }

    private fun extract(text: String, regex: String): String? {
        val m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(text)
        return if (m.find()) m.group(1) else null
    }
}

class SimpleCookieJar : CookieJar {
    private val cookies = mutableListOf<Cookie>()

    @Synchronized override fun saveFromResponse(url: HttpUrl, newCookies: List<Cookie>) {
        newCookies.forEach { incoming ->
            cookies.removeAll {
                it.name == incoming.name && it.domain == incoming.domain && it.path == incoming.path
            }
            cookies.add(incoming)
        }
    }

    @Synchronized override fun loadForRequest(url: HttpUrl): List<Cookie> =
        cookies.filter { it.matches(url) }

    @Synchronized fun findValue(name: String): String? =
        cookies.lastOrNull { it.name.equals(name, ignoreCase = true) }?.value
}
