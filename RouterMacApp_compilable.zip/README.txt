Router MAC - versión 0.1

Primera base de la app:
- conecta con http://192.168.1.1
- conserva las cookies de sesión
- intenta extraer gcsessionkey/sessionkey
- intenta leer localmac y filtermode
- prepara Bloquear/Desbloquear

Los botones todavía NO cambian el router. Primero se conectará el POST ADD
que estamos verificando para evitar perder la conexión Wi‑Fi.
