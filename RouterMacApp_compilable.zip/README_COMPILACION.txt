Router MAC - paquete preparado para compilación en la nube

Esta versión continúa desde la investigación realizada con PCAPdroid.

Cambios de esta versión:
- conserva la misma sesión y cookies del WebView;
- si el firmware muestra una pantalla CGI de inicio de sesión, intenta iniciar sesión automáticamente con admin / system;
- también responde automáticamente si el router usa autenticación HTTP;
- localiza la página MAC Filter sin depender de una URL fija del menú;
- para BLOQUEAR, usa la función AddEntry() propia de la página MAC Filter del router;
- para DESBLOQUEAR, usa la función DelEntry() propia de la página MAC Filter del router;
- de esta forma el router genera sus propios campos ocultos, operation, sessionkey y delnumberlist exactamente como en la interfaz web capturada con PCAPdroid;
- mantiene la verificación posterior del cambio;
- el nombre de este paquete DEBE mantenerse exactamente como RouterMacApp_compilable.zip para el workflow existente.

Salida esperada:
app/build/outputs/apk/debug/app-debug.apk

Es un APK de depuración para pruebas, no una versión firmada para Play Store.
