Router MAC - paquete preparado para compilación en la nube

Se corrigió una cadena multilínea de MainActivity.kt que impedía compilar Kotlin.
Se añadió .github/workflows/build-apk.yml para compilar el APK automáticamente
con GitHub Actions usando Gradle 8.9, JDK 21 y Android SDK 35.

Salida esperada:
app/build/outputs/apk/debug/app-debug.apk

Es un APK de depuración para pruebas, no una versión firmada para Play Store.

Corrección adicional: la app ahora abre la interfaz CGI del router y sigue automáticamente el enlace MAC Filter, incluso cuando aparece dentro de un menú/frame, antes de habilitar los botones.
