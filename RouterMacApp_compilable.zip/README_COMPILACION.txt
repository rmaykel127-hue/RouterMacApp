Router MAC - paquete preparado para compilación en la nube

Corrección centrada en el flujo que ya había logrado detectar la MAC y la página MAC Filter.

Cambios de esta versión:
- conserva la misma sesión y cookies del WebView;
- si el firmware muestra una pantalla CGI de inicio de sesión, intenta iniciar sesión automáticamente con admin / system;
- también responde automáticamente si el router usa autenticación HTTP;
- después del login vuelve a buscar MAC Filter sin perder la sesión;
- mantiene la detección de MAC Filter, Source MAC Address, New/Delete y Apply;
- no depende de una sessionkey separada;
- no cambia el nombre del paquete ZIP.

Salida esperada:
app/build/outputs/apk/debug/app-debug.apk

Es un APK de depuración para pruebas, no una versión firmada para Play Store.
