Router MAC - paquete preparado para compilación en la nube

Se corrigió MainActivity.kt para mantener la sesión/cookies del router dentro del mismo WebView
y realizar las operaciones desde la propia página MAC Filter, en lugar de exigir una sessionkey
obtenida por separado.

La app:
- abre /cgi-bin/login.cgi;
- busca MAC Filter incluso dentro de frames/menús;
- mantiene cookies y navegación CGI en el mismo WebView;
- habilita Bloquear/Desbloquear al encontrar Source MAC/MAC Filter;
- usa los botones New/Delete/Apply de la propia página del router;
- verifica el cambio después de una recarga de la página;
- no depende de un nombre fijo de campo MAC ni de una sessionkey separada.

Salida esperada:
app/build/outputs/apk/debug/app-debug.apk

Es un APK de depuración para pruebas, no una versión firmada para Play Store.
